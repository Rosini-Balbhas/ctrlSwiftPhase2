import React from "react";
import PartnerHeader from "../components/partnerHeader";
import Footer from "../components/footer/Footer";
import { Carousel } from "react-bootstrap";

import backgroundImage11 from "../images/l2.png";
import backgroundImage12 from "../images/l3.png";

class partnerHome extends React.Component {
  render() {
    return (
      <div>
        <div>
          <PartnerHeader />
        </div>

        <div>
          <div>
            <section class="generic-banner relative banner-area-inner2">
              <div class="overlay overlay-bg "></div>
              <div class="container">
                <div class="row height  align-items-center justify-content-center">
                  <div class="col-lg-10">
                    <div class="generic-banner-content">
                      <h2 class="head2-inner">Partners</h2>
                      <p class="text-white" style={{ opacity: 0.5 }}></p>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
          <section>
            <Carousel>
              <Carousel.Item>
                <h1 style={{ marginTop: 50 }}>Our Partners</h1>
                <div className="row" style={{ marginTop: 100 }}>
                  <a class="col single-img" href="#">
                    <img
                      src={backgroundImage11}
                      className="d-block mx-auto"
                      alt="smaple image"
                    />
                  </a>

                  <a class="col single-img" href="#">
                    <img
                      src={backgroundImage12}
                      className="d-block mx-auto"
                      alt="smaple image"
                    />
                  </a>
                </div>
              </Carousel.Item>
            </Carousel>
          </section>
        </div>

        <Footer />
      </div>
    );
  }
}
export default partnerHome;
