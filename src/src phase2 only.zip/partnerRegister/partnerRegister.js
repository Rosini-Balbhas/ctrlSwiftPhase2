import React from "react";
import {
  Container,
  Row,
  Col,
  Form,
  Button,
  Text,
  Modal,
  Alert,
} from "react-bootstrap";

import Footer from "../components/footer/Footer.js";
import Swal from "sweetalert2";
import { Redirect } from "react-router";
import { connect } from "react-redux";
import { submitpartner, requestloadcitybycountry } from "./action";
import { PropTypes } from "prop-types";
import Loader from "../components/loading";

class partnerRegister extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      company: "",
      companyError: "",
      companyUrl: "",
      companyUrlError: "",
      email: "",
      emailError: "",
      countryCode: "",
      countryCodeError: "",
      mobile: "",
      mobileError: "",
      landLineCode: "",
      landLineCodeError: "",
      landlineNumber: "",
      landlineNumberError: "",
      address: "",
      addressError: "",
      city: "",
      cityError: "",
      pincode: "",
      pincodeError: "",
      state: "",
      stateError: "",
      country: "",
      countryError: "",
      gstNumber: "",
      gstNumberError: "",
      submitted: false,
      isSuccess: false,
      // isLoginSuccess: false,
      isReadyToRedirect: false,
      isRegisterForm: true,
      AccountNumber: "",
      AccountNumberError: "",
      AccountNumber2: "",
      AccountNumber2Error: "",
      ifscCode: "",
      IFSCError: "",
      termsCondition: false,
      checkBox: false,
      BankName: "",
      branchName: "",
      swiftCode: "",
      alertbox: false,
      submittedNext: false,
      submittedRegiter: false,
      cancelledChequeLeaf: "",
      bankPassbook: "",
      submitAccept: false,
      pincodeError: "",
    };
    this.handleChange = this.handleChange.bind(this);
    // this.handleSubmit = this.handleSubmit.bind(this);
    // this.handleCitySelectChange = this.handleCitySelectChange.bind(this);
    // this.handleCountryChange = this.handleCountryChange.bind(this);
    // this.handleCompanySelectChange = this.handleCompanySelectChange.bind(this);
    this.ChangeRegisterFormBack = this.ChangeRegisterFormBack.bind(this);
    // this.openTC = this.openTC.bind(this);
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
  };

  changeMobile = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });

    if (value.length < 10) {
      this.setState({
        mobileError: "Invalid mobile number",
      });
      console.log("changing mobile" + this.state.mobileError);
    } else if (value.length > 10) {
      this.setState({
        mobileError: "Invalid mobile number",
      });
      console.log("changing mobile" + this.state.mobileError);
    } else {
      this.setState({
        mobileError: "",
      });
      console.log("changing mobile" + this.state.mobileError);
    }
  };

  Change = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /^[A-Za-z_ ]+$/;

    if (!re.test(value)) {
      this.setState({
        companyError: "Please enter the valid company name",
      });
    } else {
      this.setState({
        companyError: "",
      });
    }
  };
  ChangeAccountno = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /^[A-Za-z_]+$/;

    if (value.length < 9) {
      this.setState({
        AccountNumberError: "Please enter the valid Account no",
      });
    } else if (value.length > 19) {
      this.setState({
        AccountNumberError: "Please enter the valid Account no",
      });
    } else {
      this.setState({
        AccountNumberError: "",
      });
    }
  };

  ChangePincodeno = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /^[A-Za-z_]+$/;

    if (value.length < 6) {
      this.setState({
        pincodeError: "Please enter the valid Pincode",
      });
    } else if (value.length > 6) {
      this.setState({
        pincodeError: "Please enter the valid Pincode",
      });
    } else {
      this.setState({
        pincodeError: "",
      });
    }
  };
  ChangeAccountnoMatch = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    console.log(value);
    if (value !== this.state.AccountNumber) {
      this.setState({
        AccountNumber2Error: "Entered Account no Mismatch",
      });
    } else if (value == this.state.AccountNumber) {
      this.setState({
        AccountNumber2Error: "",
      });
    }
  };

  //-------
  ChangeIFSC = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /^[A-Za-z]{4}\d{7}$/;

    if (!re.test(value)) {
      this.setState({
        IFSCError: "Please enter the valid IFSC",
      });
    } else if (value.length < 11) {
      this.setState({
        IFSCError: "Please enter the valid IFSC",
      });
    } else if (value.length > 11) {
      this.setState({
        IFSCError: "Please enter the valid IFSC",
      });
    } else {
      this.setState({
        IFSCError: "",
      });
    }
  };

  ChangeLastName = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const yu = /^[A-Za-z_ ]+$/;

    if (!yu.test(value)) {
      this.setState({
        companyUrlError: "Please enter the valid company url",
      });
    } else {
      this.setState({
        companyUrlError: "",
      });
    }
  };

  handleChanges = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /\S+@[A-Za-z]+\.com/;
    const ks = /\S+@[A-Za-z]+\.co.in/;
    if (!re.test(value) && !ks.test(value)) {
      this.setState({
        emailError: "Please enter the valid email",
      });
    } else {
      this.setState({
        emailError: "",
      });
    }
  };

  file = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let cancelledChequeLeaf = e.target.files[0];
      console.log("cancelledChequeLeaf" + e.target.files[0]);
      // const fileSize = e.target.files[0].size;
      // const fsize = Math.round((fileSize / 1024));
      // const base64 = this.convertBase64(file);
      console.log(this.statebase64);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log("cancelledChequeLeaf" + cancelledChequeLeaf);

      console.log(cancelledChequeLeaf.type);
      if (
        cancelledChequeLeaf.type === "image/png" ||
        cancelledChequeLeaf.type === "image/jpeg"
      ) {
        this.setState({ cancelledChequeLeaf: cancelledChequeLeaf });
        /*if(fsize<1025 && fsize>1){
       this.setState({file:file})
      }else{
      document.getElementById("exampleFormControlFile1").value =''
      this.setState({file:''})
      Swal.fire({
       title: "",
       text: "File Size Should Be Minimum 2KB and Maximun 1024KB",
       icon: 'warning',
       showCancelButton: false,
       confirmButtonColor: '#3085d6',
       cancelButtonColor: '#d33',
       confirmButtonText: 'OK'
      }) 
      }*/
      } else if (
        cancelledChequeLeaf.type !== "image/png" &&
        cancelledChequeLeaf.type !== "image/jpeg"
      ) {
        document.getElementById("exampleFormControlFile1").value = "";
        this.setState({ cancelledChequeLeaf: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        cancelledChequeLeaf: "",
      });
    }
  };
  bankPassbook = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let bankPassbook = e.target.files[0];
      console.log("bankPassbook" + e.target.files[0]);
      // const fileSize = e.target.files[0].size;
      // const fsize = Math.round((fileSize / 1024));
      // const base64 = this.convertBase64(file);
      console.log(this.statebase64);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log("bankPassbook" + bankPassbook);

      console.log(bankPassbook.type);
      if (
        bankPassbook.type === "image/png" ||
        bankPassbook.type === "image/jpeg"
      ) {
        this.setState({ bankPassbook: bankPassbook });
        /*if(fsize<1025 && fsize>1){
       this.setState({file:file})
      }else{
      document.getElementById("exampleFormControlFile1").value =''
      this.setState({file:''})
      Swal.fire({
       title: "",
       text: "File Size Should Be Minimum 2KB and Maximun 1024KB",
       icon: 'warning',
       showCancelButton: false,
       confirmButtonColor: '#3085d6',
       cancelButtonColor: '#d33',
       confirmButtonText: 'OK'
      }) 
      }*/
      } else if (
        bankPassbook.type !== "image/png" &&
        bankPassbook.type !== "image/jpeg"
      ) {
        // document.getElementById("exampleFormControlbankPassbook1").value = "";
        this.setState({ bankPassbook: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        bankPassbook: "",
      });
    }
  };

  handleCountryChange = (event) => {
    const { country, value } = event.target;

    this.setState({
      country: value,
    });
    console.log(value);
  };

  ChangeRegisterForm = () => {
    this.setState({ submittedNext: true });
    const {
      company,
      companyUrl,
      email,
      city,
      countryCode,
      mobile,

      address,
      pincode,
      state,
      country,
      gstNumber,
      submittedNext,
      mobileError,
      pincodeError,
    } = this.state;

    if (
      company &&
      email &&
      city &&
      countryCode &&
      mobile &&
      address &&
      pincode &&
      state &&
      country &&
      gstNumber &&
      mobileError == "" &&
      pincodeError == ""
    ) {
      this.setState({
        isRegisterForm: false,
      });
    }
  };
  ChangeRegisterFormBack = () => {
    console.log("---------------working back-------");
    this.setState({
      isRegisterForm: true,
    });
  };
  openTc = () => {
    this.setState({ submittedRegiter: true });
    console.log("==============in register button============");
    const {
      AccountNumber,
      AccountNumber2,
      ifscCode,
      BankName,
      branchName,
      swiftCode,
      cancelledChequeLeaf,
      bankPassbook,
      IFSCError,
      AccountNumberError,
      AccountNumber2Error,
    } = this.state;
    if (
      AccountNumber &&
      ifscCode &&
      BankName &&
      branchName &&
      swiftCode &&
      cancelledChequeLeaf &&
      bankPassbook &&
      IFSCError == "" &&
      AccountNumberError == "" &&
      AccountNumber2Error == "" &&
      AccountNumber2
    ) {
      this.setState({
        termsCondition: true,
      });
    }
  };

  handleClose = () => {
    this.setState({
      termsCondition: false,
    });
  };
  handleCheckbox = () => {
    if (this.state.checkBox == false) {
      this.setState({
        checkBox: true,
      });
    } else {
      this.setState({
        checkBox: false,
      });
    }

    console.log(this.state.checkBox);
  };

  handleSubmit1 = (event) => {
    event.preventDefault();
    this.setState({ submitAccept: true });
    const {
      company,
      companyUrl,
      email,
      city,
      countryCode,
      mobile,
      address,
      pincode,
      state,
      country,
      gstNumber,
      AccountNumber,
      AccountNumber2,
      ifscCode,
      BankName,
      branchName,
      swiftCode,
      cancelledChequeLeaf,
      landlineNumber,
      landLineCode,
      bankPassbook,
    } = this.state;
    if (this.state.checkBox == true) {
      console.log(
        company,
        companyUrl,
        email,
        city,
        countryCode,
        mobile,
        address,
        pincode,
        state,
        country,
        gstNumber,
        AccountNumber,
        AccountNumber2,
        ifscCode,
        BankName,
        branchName,
        swiftCode,
        cancelledChequeLeaf,
        landlineNumber,
        landLineCode,
        bankPassbook
      );
      const formData = new FormData();
      formData.append("company", company);
      formData.append("email", email);
      formData.append("countryCode", countryCode);
      formData.append("mobile", mobile);
      formData.append("address", address);
      formData.append("city", city);
      formData.append("pincode", pincode);
      formData.append("state", state);
      formData.append("country", country);
      // formData.append("companyUrl", companyUrl);
      formData.append("gstNumber", gstNumber);
      formData.append("BankName", BankName);
      formData.append("AccountNumber", AccountNumber);
      formData.append("ifscCode", ifscCode);
      formData.append("swiftCode", swiftCode);
      formData.append("branchName", branchName);
      formData.append("cancelledChequeLeaf", cancelledChequeLeaf);
      formData.append("bankPassbook", bankPassbook);
      formData.append("landlineNumber", landlineNumber);
      formData.append("landLineCode", landLineCode);

      this.props.submitpartner(formData);
      console.log("=======formData========" + JSON.stringify(formData));

      // Swal.fire({
      //   text: "Your Application in process",
      //   confirmButtonColor: "#3085d6",
      //   confirmButtonText: "ok ",
      // });
      // .then(function(){
      //   window.location="/"
      // });
      // this.props.history.push("/HomePage");
    } else if (this.state.checkBox == false) {
      this.setState({
        checkBoxError: "Accept Terms & Condition",
      });
      this.setState({ alertbox: true }, () => {
        window.setTimeout(() => {
          this.setState({ alertbox: false });
        }, 3000);
      });
    }
  };

  componentDidMount() {
    var x = { a: 2 };
    var y = x;
    console.log("before \n x \n" + x.a + "\n y\n" + y.a);
    x.a += x.a;
    console.log("after \n x \n" + x.a + "\n y\n" + y.a);
    // this.props.requestloadcitybycountry();
    console.log("Calling load cities list....................");
    console.log("country in index  ...................." + this.state.country);

    // this.props.requestloadcompany();
    console.log("company  ...................." + this.state.company);

    console.log("----companylist---" + this.props.companylist);
  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    if (this.props.isSuccess !== prevProps.isSuccess) {
      if (
        this.state.submitAccept &&
        this.props.isSuccess &&
        this.props.isSuccess.success
      ) {
        console.log(this.props.isSuccess.message);
        Swal.fire({
          title: "Thank You !",
          text: this.props.isSuccess.message,
          icon: "success",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
        this.setState({ isLoading: false, isReadyToRedirect: true });
      } else if (this.state.submitAccept && !this.props.isSuccess.success) {
        Swal.fire({
          title: "",
          text: this.props.isSuccess.message,
          icon: "info",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
        this.setState({ isReadyToRedirect: false, isLoading: false });
      }
    }
  }

  render() {
    if (this.state.isReadyToRedirect) return <Redirect to="/" />;
    const {
      company,
      companyUrl,
      email,
      countryCode,
      mobile,
      landLineCode,
      landlineNumber,
      address,
      city,
      pincode,
      state,
      country,
      gstNumber,
      submitted,
      swiftCode,
      AccountNumber,
      AccountNumber2,
      ifscCode,
      checkBox,
      BankName,
      branchName,
      submittedNext,
      submittedRegiter,
      cancelledChequeLeaf,
      bankPassbook,
    } = this.state;

    return (
      <div>
        {/* <HeaderSign /> */}
        {this.state.isLoading ? (
          <Loader />
        ) : (
          <div>
            <div className="view">
              <section class="generic-banner relative banner-area-inner1">
                <div
                  class="overlay overlay-bg overlay-bg-blk"
                  style={{ backgroundColor: "black", opacity: 0.5 }}
                ></div>
                <div class="container">
                  <div class="row height align-items-center justify-content-center">
                    <div class="col-lg-10">
                      <div class="generic-banner-content inner-banner-txt"></div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
            <br />
            <Container>
              <Row>
                <Col>
                  <p style={{ fontSize: 26, color: "black" }}>
                    To register, please take the time to fill out the
                    information below.
                  </p>
                </Col>
              </Row>
            </Container>

            {this.state.isRegisterForm == true ? (
              <Container>
                <Form>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="company">
                      <Form.Label>
                        Company Name<i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        autocomplete="off"
                        className="form-control"
                        required
                        pattern="[0-9a-zA-Z_.-]*"
                        onChange={this.Change}
                        name="company"
                        value={company}
                        id="p"
                      />
                      {submittedNext && !company && (
                        <div className="validationError nav-left nav-left">
                          Company is required
                        </div>
                      )}
                      {submittedNext &&
                        this.state.companyError !== "" &&
                        company && (
                          <div className="validationError">
                            {this.state.companyError}
                          </div>
                        )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="companyUrl">
                      <Form.Label>Company Website</Form.Label>
                      <input
                        type="text"
                        autocomplete="off"
                        className="form-control"
                        required
                        pattern="[0-9a-zA-Z_.-]*"
                        onChange={this.ChangeLastName}
                        name="companyUrl"
                        value={companyUrl}
                      />
                      {/* {submittedNext && !companyUrl && (
                        <div className="validationError nav-left">
                          {" "}
                          Company Url is required
                        </div>
                      )} */}
                      {submittedNext &&
                        this.state.companyUrlError !== "" &&
                        companyUrl && (
                          <div className="validationError">
                            {this.state.companyUrlError}
                          </div>
                        )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="email">
                      <Form.Label>
                        Email<i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="text"
                        autocomplete="off"
                        className="form-control"
                        name="email"
                        value={email}
                        onChange={this.handleChanges}
                      />
                      {submittedNext && !email && (
                        <div className="validationError nav-left">
                          Work Mail is required
                        </div>
                      )}
                      {submittedNext &&
                        this.state.emailError !== "" &&
                        email && (
                          <div className="validationError">
                            {this.state.emailError}
                          </div>
                        )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="city">
                      <Form.Label>
                        City<i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        className="form-control"
                        name="city"
                        value={city}
                        onChange={this.handleChange}
                      />
                      {submittedNext && !city && (
                        <div className="validationError nav-left">
                          city is required
                        </div>
                      )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} sm="2" controlId="countryCode">
                      <Form.Label>
                        Country Code <i className="validationError">*</i>
                      </Form.Label>
                      <select
                        type="dropdown"
                        className="form-control"
                        name="countryCode"
                        value={countryCode}
                        placeholder="select"
                        onChange={this.handleChange}
                      >
                        <option value=""></option>

                        <option value="+91">+91</option>
                        <option value="+1">+1</option>
                        <option value="+86">+86</option>
                        <option value="+44">+44</option>
                        <option value="+81">+81</option>
                        <option value="+49">+49</option>
                        <option value="+33">+33</option>
                        <option value="+55">+55</option>
                        <option value="+39">+39</option>
                        <option value="+1">+1</option>
                        <option value="+7">+7</option>
                        <option value="+65">+65</option>
                        <option value="+64">+64</option>
                        <option value="+61">+61</option>
                        <option value="+964">+964</option>
                      </select>
                      {submittedNext && !countryCode && (
                        <div className="validationError nav-left">
                          Mobile code is required
                        </div>
                      )}
                    </Form.Group>
                    <Form.Group as={Col} md="4" controlId="mobile">
                      <Form.Label>
                        Mobile <i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="number"
                        className="form-control"
                        name="mobile"
                        value={mobile}
                        minLength="15"
                        maxLength="15"
                        onChange={this.changeMobile}
                        format="##########"
                      />
                      {submittedNext && !mobile && (
                        <div className="validationError nav-left">
                          Mobile is required
                        </div>
                      )}
                      {submittedNext &&
                        this.state.mobileError !== "" &&
                        mobile && (
                          <div className="validationError">
                            {this.state.mobileError}
                          </div>
                        )}
                    </Form.Group>
                    <Form.Group as={Col} sm="2" controlId="landLineCode">
                      <Form.Label>Land Line Code</Form.Label>
                      <input
                        type="number"
                        className="form-control"
                        name="landLineCode"
                        value={landLineCode}
                        onChange={this.handleChange}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md="4" controlId="landlineNumber">
                      <Form.Label>Landline</Form.Label>
                      <input
                        type="number"
                        autocomplete="off"
                        className="form-control"
                        name="landlineNumber"
                        value={landlineNumber}
                        onChange={this.handleChange}
                        maxLength={8}
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="country">
                      <Form.Label>
                        Country <i className="validationError">*</i>
                      </Form.Label>

                      <select
                        type="dropdown"
                        className="form-control"
                        name="country"
                        value={country}
                        placeholder="select"
                        onChange={this.handleCountryChange}
                      >
                        <option value=""></option>
                        <option value="India">India</option>
                        <option value="US">US</option>
                        <option value="China">China</option>
                        <option value="UK">Uk</option>
                        <option value="Japan">Japan</option>
                        <option value="Germany">Germany</option>
                        <option value="France">France</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Italy">Italy</option>
                        <option value="Canada">Canada</option>
                        <option value="Russia">Russia</option>
                        <option value="Singapore">Singapore</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Australia">Australia</option>
                        <option value="Iraq">Iraq</option>
                      </select>

                      {submittedNext && !country && (
                        <div className="validationError nav-left">
                          Country is required
                        </div>
                      )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="state">
                      <Form.Label>
                        State <i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        className="form-control"
                        name="state"
                        value={state}
                        onChange={this.handleChange}
                      ></input>

                      {submittedNext && !state && (
                        <div className="validationError nav-left">
                          state is required
                        </div>
                      )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="address">
                      <Form.Label>
                        Address <i className="validationError">*</i>
                      </Form.Label>
                      <textarea
                        className="form-control"
                        name="address"
                        value={address}
                        onChange={this.handleChange}
                      />
                      {submittedNext && !address && (
                        <div className="validationError nav-left">
                          Address is required
                        </div>
                      )}
                      {submittedNext && address && address.length < 4 && (
                        <div className="validationError nav-left">
                          Address is too short, Please provide detailed address
                        </div>
                      )}
                    </Form.Group>

                    <Form.Group as={Col} md="6" controlId="pincode">
                      <Form.Label>
                        Pincode<i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="number"
                        className="form-control"
                        name="pincode"
                        value={pincode}
                        onChange={this.ChangePincodeno}
                      />
                      {submittedNext && !pincode && (
                        <div className="validationError nav-left">
                          Pincode is required
                        </div>
                      )}

                      {submittedNext &&
                        this.state.pincodeError !== "" &&
                        pincode && (
                          <div className="validationError">
                            {this.state.pincodeError}
                          </div>
                        )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="gstNumber">
                      <Form.Label>
                        Gst No<i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="text"
                        className="form-control"
                        name="gstNumber"
                        value={gstNumber}
                        onChange={this.handleChange}
                      />
                      {submittedNext && !gstNumber && (
                        <div className="validationError nav-left">
                          GST No is required
                        </div>
                      )}
                    </Form.Group>
                  </Form.Row>

                  <Form.Row>
                    <Form.Group as={Col} sm="11" />
                    <Form.Group as={Col} sm="1" controlId="register">
                      <Button
                        className=" primary radius text-uppercase"
                        onClick={this.ChangeRegisterForm}
                      >
                        next
                      </Button>
                    </Form.Group>
                  </Form.Row>
                </Form>
              </Container>
            ) : (
              <Container>
                <h3>Bank information</h3>
                <br />
                <Form>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="AccountNumber">
                      <Form.Label>
                        Account No<i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        autocomplete="off"
                        className="form-control"
                        required
                        pattern="[0-9a-zA-Z_.-]*"
                        onChange={this.ChangeAccountno}
                        name="AccountNumber"
                        value={AccountNumber}
                      />
                      {submittedRegiter && !AccountNumber && (
                        <div className="validationError nav-left">
                          Account No is required
                        </div>
                      )}
                      {submittedRegiter &&
                        this.state.AccountNumberError !== "" &&
                        AccountNumber && (
                          <div className="validationError">
                            {this.state.AccountNumberError}
                          </div>
                        )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="AccountNumber2">
                      <Form.Label>
                        Re-Enter Account no<i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="text"
                        autocomplete="off"
                        className="form-control"
                        required
                        pattern="[0-9a-zA-Z_.-]*"
                        onChange={this.ChangeAccountnoMatch}
                        name="AccountNumber2"
                        value={AccountNumber2}
                      />
                      {submittedRegiter && !AccountNumber2 && (
                        <div className="validationError nav-left">
                          {" "}
                          Account no Mismatching
                        </div>
                      )}
                      {submittedRegiter &&
                        this.state.AccountNumber2Error !== "" &&
                        AccountNumber2 && (
                          <div className="validationError">
                            {this.state.AccountNumber2Error}
                          </div>
                        )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="ifscCode">
                      <Form.Label>
                        IFSC Code<i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        autocomplete="off"
                        className="form-control"
                        required
                        pattern="[0-9a-zA-Z_.-]*"
                        onChange={this.ChangeIFSC}
                        name="ifscCode"
                        value={ifscCode}
                      />
                      {submittedRegiter && !ifscCode && (
                        <div className="validationError nav-left">
                          IFsc Code is required*
                        </div>
                      )}
                      {submittedRegiter &&
                        this.state.IFSCError !== "" &&
                        ifscCode && (
                          <div className="validationError">
                            {this.state.IFSCError}
                          </div>
                        )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="taxId">
                      <Form.Label>
                        {" "}
                        Cancelled check Leaf<i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="file"
                        accept="image/png, image/jpeg"
                        class="form-control-file"
                        id="exampleFormControlFile1"
                        name="cancelledChequeLeaf"
                        style={{ borderBlockStyle: "outset" }}
                        onChange={(e) => this.file(e)}
                      />
                      {submittedRegiter && !cancelledChequeLeaf && (
                        <div className="validationError nav-left">
                          file is required
                        </div>
                      )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="company">
                      <Form.Label>
                        Bank Name<i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        className="form-control"
                        name="BankName"
                        value={this.state.BankName}
                        onChange={this.handleChange}
                        autocomplete="off"
                      />

                      {submittedRegiter && !BankName && (
                        <div className="validationError nav-left">
                          Bank Name is required
                        </div>
                      )}
                    </Form.Group>
                    <Form.Group
                      as={Col}
                      md="6"
                      controlId="companyUrl"
                      autoComplete="off"
                    >
                      <Form.Label>
                        Branch <i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="text"
                        className="form-control"
                        name="branchName"
                        value={this.state.branchName}
                        onChange={this.handleChange}
                        autocomplete="off"
                      />

                      {submittedRegiter && !branchName && (
                        <div className="validationError nav-left">
                          Branch is required
                        </div>
                      )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6" controlId="company">
                      <Form.Label>
                        Swift Code<i className="validationError">*</i>
                      </Form.Label>

                      <input
                        type="text"
                        className="form-control"
                        name="swiftCode"
                        value={this.state.swiftCode}
                        onChange={this.handleChange}
                        autocomplete="off"
                      />

                      {submittedRegiter && !swiftCode && (
                        <div className="validationError nav-left">
                          Swift Code is required
                        </div>
                      )}
                    </Form.Group>
                    <Form.Group as={Col} md="6" controlId="taxId">
                      <Form.Label>
                        {" "}
                        Bank Passbook<i className="validationError">*</i>
                      </Form.Label>
                      <input
                        type="file"
                        accept="image/png, image/jpeg"
                        class="form-control-file"
                        id="exampleFormControlFile1"
                        name="bankPassbook"
                        style={{ borderBlockStyle: "outset" }}
                        onChange={(e) => this.bankPassbook(e)}
                      />
                      {submittedRegiter && !bankPassbook && (
                        <div className="validationError nav-left">
                          file is required
                        </div>
                      )}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md="6">
                      <Button
                        className=" primary radius text-uppercase"
                        onClick={this.ChangeRegisterFormBack}
                      >
                        <i class="glyphicon glyphicon-chevron-left" />
                        Back
                      </Button>
                    </Form.Group>
                    <Form.Group as={Col} md="6">
                      <Button
                        className=" primary radius text-uppercase"
                        onClick={this.openTc}
                      >
                        Register
                      </Button>
                    </Form.Group>
                  </Form.Row>
                </Form>
              </Container>
            )}
            <br />
            <Modal
              show={this.state.termsCondition}
              onHide={this.handleClose}
              backdrop={"static"}
            >
              <Modal.Header closeButton>TERMS AND CONDITION</Modal.Header>
              <Modal.Body>
                A Terms and Conditions agreement outlines the terms that
                visitors must agree to if they want to interact with your
                website. Essentially, if the visitor continues to use the
                website after accepting the Terms, they enter into a contract
                with you.
              </Modal.Body>
              <Modal.Footer>
                <Form.Check
                  type="checkbox"
                  label="Click here to accept the terms and conditions"
                  name="checkBox"
                  onClick={this.handleCheckbox}
                  value={checkBox}
                />
                {this.state.alertbox == true ? (
                  <div>
                    {this.state.checkBoxError !== "" && (
                      <div>
                        <Alert variant="danger">
                          {this.state.checkBoxError}
                        </Alert>
                      </div>
                    )}
                  </div>
                ) : null}

                <Button
                  className=" primary radius text-uppercase"
                  onClick={this.handleSubmit1}
                >
                  Accept
                </Button>
              </Modal.Footer>
            </Modal>

            <Footer />
          </div>
        )}
      </div>
    );
  }
}

partnerRegister.propTypes = {
  submitpartner: PropTypes.func,
};
const mapStateToProps = (state) => {
  return {
    isSuccess: state.partnerRegisterReducer.isSuccess,
  };
};

const mapDispatchToProps = (dispatch) => ({
  submitpartner: (data) => dispatch(submitpartner(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(partnerRegister);
