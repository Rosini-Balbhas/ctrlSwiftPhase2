// import * as Constants from "../constants";

// // export const validateOtpData = (state) => ({
// //   type: Constants.VALIDATE_OTP_DATE,
// //   url: Constants.API_URLS.OTP_SUCCESS_URL,
// //   state,
// // });

// export const partnerForgotOtp = (email, otp) => ({
//   type: Constants.PARTNER_FORGOTPASSWORD_VERIFY_OTP, //this will match with your saga
//   url: Constants.API_URLS.PARTNER_VERIFY_OTP_URL,
//   email,
//   otp,
// });

// export const partnerForgotOtpResponse = (isValidatdOtpSuccess) => ({
//   type: Constants.PARTNER_FORGOTPASSWORD_VERIFY_OTP_RESPONSE,
//   isValidatdOtpSuccess,
// });

// export const partnerResendOtp = (email, otp) => ({
//   type: Constants.PARTNER_RESENDOTP_VERIFY, //this will match with your saga
//   url: Constants.API_URLS.PARTNER_RESENDOTP_URL,
//   email,
//   otp,
// });

// export const partnerResendOtpResponse = (resendOtpSuccess) => ({
//   type: Constants.PARTNER_RESENDOTP_RESPONSE,
//   resendOtpSuccess,
// });
