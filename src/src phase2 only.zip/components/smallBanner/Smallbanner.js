import React from "react";
import backgroundImage6 from "../../images/s3.jpg";
import backgroundImage7 from "../../images/s1.jpg";
import backgroundImage8 from "../../images/s4.jpg";
import backgroundImage26 from "../../images/b1desk-lite01.jpg";
import { Button, NavLink } from "react-bootstrap";
import Carousel from "react-bootstrap/Carousel";
import { PropTypes } from "prop-types";
import { connect } from "react-redux";
import { SmallbannerList } from "./action";
import { useScrollTrigger } from "@material-ui/core";
import { Link, Redirect } from "react-router-dom";
import { Nav } from "react-bootstrap";

class Smallbanner extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isSuccess: false,
      litePlan: "",
      enterprisePlan: "",
      premiumPlan: "",
      duplicateLitePlan: "",
    };
  }
  componentDidMount() {
    this.props.SmallbannerList();
    // this.setState({
    //   litePlan:this.props.isSuccess.litePlan,
    //   enterprisePlan:this.props.isSuccess.enterprisePlan,
    //   duplicateLitePlan:this.props.isSuccess.duplicateLitePlan,
    // });
    // console.log(this.state.enterprisePlan);
  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("" + JSON.stringify(this.props.isSuccess));
    if (this.props.isSuccess !== prevProps.isSuccess) {
      if (
        this.props.isSuccess !== undefined &&
        this.props.isSuccess !== null &&
        this.props.isSuccess.litePlan !== undefined
      ) {
        this.setState({
          litePlan: this.props.isSuccess.litePlan,
        });
      }
    }
    if (this.props.isSuccess !== prevProps.isSuccess) {
      if (
        this.props.isSuccess !== undefined &&
        this.props.isSuccess !== null &&
        this.props.isSuccess.enterprisePlan !== undefined
      ) {
        this.setState({
          enterprisePlan: this.props.isSuccess.enterprisePlan,
        });
      }
    }
    if (this.props.isSuccess !== prevProps.isSuccess) {
      if (
        this.props.isSuccess !== undefined &&
        this.props.isSuccess !== null &&
        this.props.isSuccess.premiumPlan !== undefined
      ) {
        this.setState({
          premiumPlan: this.props.isSuccess.premiumPlan,
        });
      }
    }
    if (this.props.isSuccess !== prevProps.isSuccess) {
      if (
        this.props.isSuccess !== undefined &&
        this.props.isSuccess !== null &&
        this.props.isSuccess.duplicateLitePlan !== undefined
      ) {
        this.setState({
          duplicateLitePlan: this.props.isSuccess.duplicateLitePlan,
        });
      }
    }
    console.log(
      JSON.stringify(this.state.litePlan) +
        "--" +
        JSON.stringify(this.state.premiumPlan) +
        "--" +
        JSON.stringify(this.state.enterprisePlan) +
        "---" +
        JSON.stringify(this.state.duplicateLitePlan)
    );
  }
  // nextPath(path) {
  //   this.props.history.push(path);
  // }

  // handleClick = () => {
  //   // this.props.history.push("/selfEmployedReg");
  //   window.location = "/partnerLogin";
  // };

  // handleClick = (history) => {
  //   history.push("/partnerLogin");
  // };
  // Route = ({ path, children }) => {
  //   return window.location.pathname === path ? children : null;
  // };

  render() {
    return (
      <div className="">
        <section
          class="pricingplans-area pb-100"
          style={{ marginTop: -230 }}
          id="pricingplans"
        >
          <div>
            <Carousel className="view">
              <Carousel.Item>
                <div class="container-fluid" id="pricingplans">
                  <div class="row no-padding">
                    <div
                      class="active-speaker-carusel col-lg-6 no-padding img-r"
                      style={{ padding: "0px" }}
                    >
                      <div class="single-speaker item">
                        <div class="container">
                          <div class="row align-items-center">
                            <div class="col-md-6 speaker-img no-padding">
                              <img
                                src={backgroundImage6}
                                className="col-md-6 speaker-img no-padding"
                                alt="smaple image"
                              />
                            </div>
                            <div class="col-md-6 speaker-info no-padding">
                              <div class="head6" style={{ textAlign: "left" }}>
                                CtrlSwift <br /> {"  "}{" "}
                                {this.state.litePlan.plan}
                              </div>
                              <div>
                                <div style={{ textAlign: "left" }}>
                                  <div class="divider"></div>
                                  <span class="head5"> Pay Per Use</span>
                                  <h4
                                    class="head4"
                                    style={{ marginBottom: 12 }}
                                  >
                                    {this.state.litePlan.payPerUse}$
                                  </h4>
                                  <p>Close upto 50 Tickets with 0 cost</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5"> Shared</span>
                                  <h4 class="head4">
                                    {this.state.litePlan.shared}$
                                  </h4>
                                  <p>Per ticket/per hour whichever is lesser</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5">Dedicated</span>

                                  <h4 class="head4">
                                    {this.state.litePlan.dedicated}$
                                  </h4>
                                  <p>Per Hour</p>
                                </div>
                                <div
                                  class="bottom-part"
                                  style={{ textAlign: "left" }}
                                >
                                  <Button
                                    className="genric-btn primary radius text-uppercase lite-color "
                                    variant=" "
                                    href="/ctrlSwiftlite"
                                  >
                                    Learn More
                                  </Button>
                                </div>
                                <div></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="active-speaker-carusel col-lg-6 no-padding img-r"
                      style={{ padding: "0px" }}
                    >
                      <div class="single-speaker item">
                        <div class="container">
                          <div class="row align-items-center">
                            <div class="col-md-6 speaker-img no-padding">
                              <img
                                src={backgroundImage7}
                                className="col-md-6 speaker-img no-padding"
                                alt="smaple image"
                              />
                            </div>
                            <div class="col-md-6 speaker-info no-padding">
                              <div class="head6" style={{ textAlign: "left" }}>
                                CtrlSwift <br />{" "}
                                {this.state.enterprisePlan.plan}
                              </div>
                              <div>
                                <div style={{ textAlign: "left" }}>
                                  <div class="divider"></div>
                                  <span class="head5"> Pay Per Use</span>
                                  <h4
                                    class="head4"
                                    style={{ marginBottom: 12 }}
                                  >
                                    {this.state.enterprisePlan.payPerUse}$
                                  </h4>
                                  <p>Close upto 50 Tickets with 0 cost</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5"> Shared</span>
                                  <h4 class="head4">
                                    {this.state.enterprisePlan.shared}$
                                  </h4>
                                  <p>Per ticket/per hour whichever is lesser</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5">Dedicated</span>

                                  <h4 class="head4">
                                    {this.state.enterprisePlan.dedicated}$
                                  </h4>
                                  <p>Per Hour</p>
                                </div>
                                <div
                                  class="bottom-part"
                                  style={{ textAlign: "left" }}
                                >
                                  <Button
                                    className="genric-btn primary radius text-uppercase lite-color "
                                    variant=" "
                                    // onClick={() =>
                                    //   this.nextPath("./selfEmployedReg")
                                    // }
                                    onClick={() => {
                                      window.location = "/partnerLogin";
                                    }}
                                    // href="/ctrlSwiftlite"
                                    // onClick={this.Route(
                                    //   partnerLogin,
                                    //   partnerLogin
                                    // )}
                                  >
                                    {/* <Redirect
                                      onClick={() => {
                                        this.state.to = "/partnerLogin";
                                      }}
                                    /> */}
                                    Learn More
                                  </Button>
                                </div>
                                <div></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Carousel.Item>
              <Carousel.Item>
                <div class="container-fluid" id="pricingplans">
                  <div class="row no-padding">
                    <div
                      class="active-speaker-carusel col-lg-6 no-padding img-r"
                      style={{ padding: "0px" }}
                    >
                      <div class="single-speaker item">
                        <div class="container">
                          <div class="row align-items-center">
                            <div class="col-md-6 speaker-img no-padding">
                              <img
                                src={backgroundImage8}
                                className="col-md-6 speaker-img no-padding"
                                alt="smaple image"
                              />
                            </div>
                            <div class="col-md-6 speaker-info no-padding">
                              <div class="head6" style={{ textAlign: "left" }}>
                                CtrlSwift <br /> {this.state.premiumPlan.plan}
                              </div>
                              <div>
                                <div style={{ textAlign: "left" }}>
                                  <div class="divider"></div>
                                  <span class="head5"> Pay Per Use</span>
                                  <h4
                                    class="head4"
                                    style={{ marginBottom: 12 }}
                                  >
                                    {this.state.premiumPlan.payPerUse}$
                                  </h4>
                                  <p>Close upto 50 Tickets with 0 cost</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5"> Shared</span>
                                  <h4 class="head4">
                                    {this.state.premiumPlan.shared}$
                                  </h4>
                                  <p>Per ticket/per hour whichever is lesser</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5">Dedicated</span>

                                  <h4 class="head4">
                                    {this.state.premiumPlan.dedicated}$
                                  </h4>
                                  <p>Per Hour</p>
                                </div>
                                <div
                                  class="bottom-part"
                                  style={{ textAlign: "left" }}
                                >
                                  <Button
                                    className="genric-btn primary radius text-uppercase lite-color "
                                    variant=" "
                                    href="/ctrlSwiftlite"
                                  >
                                    Learn More
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="active-speaker-carusel col-lg-6 no-padding img-r"
                      style={{ padding: "0px" }}
                    >
                      <div class="single-speaker item">
                        <div class="container">
                          <div class="row align-items-center">
                            <div class="col-md-6 speaker-img no-padding">
                              <img
                                src={backgroundImage26}
                                className="col-md-6 speaker-img no-padding"
                                alt="smaple image"
                              />
                            </div>
                            <div class="col-md-6 speaker-info no-padding">
                              <div class="head6" style={{ textAlign: "left" }}>
                                CtrlSwift <br />{" "}
                                {this.state.duplicateLitePlan.plan}
                              </div>
                              <div>
                                <div style={{ textAlign: "left" }}>
                                  <div class="divider"></div>
                                  <span class="head5"> Pay Per Use</span>
                                  <h4
                                    class="head4"
                                    style={{ marginBottom: 12 }}
                                  >
                                    {this.state.duplicateLitePlan.payPerUse}$
                                  </h4>
                                  <p>Close upto 50 Tickets with 0 cost</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5"> Shared</span>
                                  <h4 class="head4">
                                    {this.state.duplicateLitePlan.shared}$
                                  </h4>
                                  <p>Per ticket/per hour whichever is lesser</p>
                                </div>
                                <div class="divider"></div>
                                <div style={{ textAlign: "left" }}>
                                  <span class="head5">Dedicated</span>

                                  <h4 class="head4">
                                    {this.state.duplicateLitePlan.dedicated}$
                                  </h4>
                                  <p>Per Hour</p>
                                </div>
                                <div
                                  class="bottom-part"
                                  style={{ textAlign: "left" }}
                                >
                                  <Button
                                    className="genric-btn primary radius text-uppercase lite-color "
                                    variant=" "
                                    href="/ctrlSwiftlite"
                                  >
                                    Learn More
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Carousel.Item>
            </Carousel>{" "}
          </div>
        </section>
      </div>
    );
  }
}
Smallbanner.propTypes = {
  SmallbannerList: PropTypes.func,
};
const mapStateToProps = (state) => {
  console.debug(state, "state");
  return {
    //Taxs: state.serviceTaxReducer.Taxs,
    isSuccess: state.smallbannerRerducer.isSuccess,
  };
};

const mapDispatchToProps = (dispatch) => ({
  SmallbannerList: (state) => dispatch(SmallbannerList(state)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Smallbanner);
