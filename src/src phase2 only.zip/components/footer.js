import React from "react";

function Footer() {
  return (
    <footer className="bdT ta-c p-10 mT-20 fsz-sm c-grey-600">
      <span>
        Copyright © 2020 Designed by{" "}
        <span className="footertext">
          <a href="http://52.255.170.184:9090/">
            <font color="#ccb200">CtrlSwift</font>
          </a>
        </span>
        . All rights reserved.
      </span>
    </footer>
  );
}
export default Footer;
