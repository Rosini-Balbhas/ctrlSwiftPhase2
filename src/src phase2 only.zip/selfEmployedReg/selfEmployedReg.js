import React, { Component } from "react";
import {
  Container,
  Row,
  Col,
  Button,
  ProgressBar,
  Form,
  InputGroup,
  FormControl,
} from "react-bootstrap";
import Logo from "../images/logo.png";
import Page from "react-page-loading";
import Swal from "sweetalert2";
import { submitselfemp,verifyAadharNumber } from "./action";
import { connect } from "react-redux";
import { PropTypes } from "prop-types";
// import { Button } from "@material-ui/core";
import { BsFillFileEarmarkArrowUpFill } from "react-icons/bs";
class selfEmployedReg extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: "",
      lastName: "",
      gender: "",
      email: "",
      mobileCountryCode: "",
      mobileNumber: "",
      landLineCode:"",
      landLineNumber:"",
      qualification: "",
      specialization: "",
      experience: "",
      address: "",
      country:"",
      city: "",
      state: "",
      pincode: "",
      aadharNumber: "",
      panCardNumber: "",
      aadharCard: "",
      experienceCertificate: "",
      addressProof: "",
      panError: "",
      IFSCError: "",
      BankName: "",
      branchName: "",
      AccountNumber: "",
      reEnterAcc: "",
      ifscCode: "",
      swiftCode: "",
      cancelledChequeLeaf: "",
      bankPassbook: "",
      ProgressBarnum: "",
      ProgressBarnum1: "",
      ProgressBarnum2: "",
      en1: false,
      en2: false,
      en3: false,
      en4: false,
      en6: false,
      showPersonalModal: true,
      showAdharModal: false,
      showFilesModal: false,
      showBankModal: false,
      showButton: false,
      showNextButton: true,
      showNextButton1: false,

      submitted: false,
      submitted1: false,
      submitted12: false,
      aadharNumberError: "",
      aadharNumber: "",
      submittedVerify: false,
      aadharError: "",
      isSelfSuccess: false,
      isAadharSuccess:false,
    };
    this.next = this.next.bind(this);
    this.back = this.back.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChange = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
  };
  handleSubmit1(e) {
    e.preventDefault();
    this.setState({ submittedVerify: true });
    console.log(
      "----testing verify======" + JSON.stringify(this.state.submittedVerify)
    );
    const { aadharNumber, aadharError } = this.state;
    if (aadharNumber != "" && aadharError == "") {
      this.props.verifyAadharNumber(aadharNumber);
      
    }

    // {
    //   adharNumber == ""
    //     ? this.setState({ adharNumberError: "enter adhar number" })
    //     : this.setState({ en6: false, submitLoader: true });
    // }
    // if(adharNumber==""){
    //   this.setState({
    //     adharNumberError:"enter adhar number",

    //   });
    // }
  }

  handleAadharChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });

    if (value.length > 12) {
      this.setState({ aadharError: "Invalid aadhar number number" });
    } else if (value.length < 12) {
      this.setState({ aadharError: "Invalid aadhar number number" });
    } else {
      this.setState({
        aadharError: "",
      });
    }
  };
  handlePanChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });

    const re = /([A-Za-z]){5}([0-9]){4}([A-Za-z]){1}$/;
    if (!re.test(value)) {
      this.setState({
        panError: "Please enter the valid pan number",
      });
    } else {
      this.setState({
        panError: "",
      });
    }
  };

  handlePhoneChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });

    if (value.length > 10) {
      this.setState({ phoneError: "Invalid Phone number" });
    } else if (value.length < 10) {
      this.setState({ phoneError: "Invalid Phone number" });
    } else {
      this.setState({
        phoneError: "",
      });
    }
  };

  convertBase64 = (aadharCard) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(aadharCard);
      fileReader.onload = () => {
        resolve(fileReader.result);
        console.log(fileReader.result);
        localStorage.setItem("file", fileReader.result);
        console.log(localStorage.getItem("file"));
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  aadharCard = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let aadharCard = e.target.files[0];
      console.log("file" + e.target.files[0]);

      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log("file" + aadharCard);
      const base64 = this.convertBase64(aadharCard);

      console.log(aadharCard.type);
      if (aadharCard.type === "image/png" || aadharCard.type === "image/jpeg") {
        this.setState({ aadharCard: aadharCard });
      } else if (
        aadharCard.type !== "image/png" &&
        aadharCard.type !== "image/jpeg"
      ) {
        // document.getElementById("exampleFormControlaadharCard").value = "";
        // this.setState({ aadharCard: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        aadharCard: "",
      });
    }
  };

  convertBase641 = (experienceCertificate) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(experienceCertificate);
      fileReader.onload = () => {
        resolve(fileReader.result);
        console.log(fileReader.result);
        localStorage.setItem("file", fileReader.result);
        console.log(localStorage.getItem("file"));
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };
  experienceCertificate = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let experienceCertificate = e.target.files[0];
      console.log("experienceCertificate" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("experienceCertificate" + experienceCertificate);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log(experienceCertificate.type);
      console.log(experienceCertificate);

      const base64 = this.convertBase641(experienceCertificate);

      if (
        experienceCertificate.type === "image/png" ||
        experienceCertificate.type === "image/jpeg"
      ) {
        this.setState({ experienceCertificate: experienceCertificate });
        // console.log(
        //   "experienceCertificate inside" + JSON.stringify(this.state.experienceCertificate)
        // );
      } else if (
        experienceCertificate.type !== "image/png" &&
        experienceCertificate.type !== "image/jpeg"
      ) {
        // document.getElementById("exampleFormControlFile").value = "";
        // this.setState({ experienceCertificate: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        experienceCertificate: "",
      });
    }
  };
  convertBase642 = (addressProof) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(addressProof);
      fileReader.onload = () => {
        resolve(fileReader.result);
        console.log(fileReader.result);
        localStorage.setItem("file", fileReader.result);
        console.log(localStorage.getItem("file"));
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  addressProof = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let addressProof = e.target.files[0];
      console.log("file" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log("file" + addressProof);
      const base64 = this.convertBase642(addressProof);

      console.log(addressProof.type);
      if (
        addressProof.type === "image/png" ||
        addressProof.type === "image/jpeg"
      ) {
        this.setState({ addressProof: addressProof });
      } else if (
        addressProof.type !== "image/png" &&
        addressProof.type !== "image/jpeg"
      ) {
        // document.getElementById("exampleFormControlFile2").value = "";
        // this.setState({ addressProof: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        addressProof: "",
      });
    }
  };
  cancelledChequeLeaf = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let cancelledChequeLeaf = e.target.files[0];
      console.log("cancelledChequeLeaf" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("cancelledChequeLeaf" + cancelledChequeLeaf);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log(cancelledChequeLeaf.type);
      console.log(cancelledChequeLeaf);

      // const base64 = this.convertBase641(cancelledChequeLeaf);

      if (
        cancelledChequeLeaf.type === "image/png" ||
        cancelledChequeLeaf.type === "image/jpeg"
      ) {
        this.setState({ cancelledChequeLeaf: cancelledChequeLeaf });
        // console.log(
        //   "cancelledChequeLeaf inside" + JSON.stringify(this.state.cancelledChequeLeaf)
        // );
      } else if (
        cancelledChequeLeaf.type !== "image/png" &&
        cancelledChequeLeaf.type !== "image/jpeg"
      ) {
        // document.getElementById("exampleFormControlFile").value = "";
        // this.setState({ cancelledChequeLeaf: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        cancelledChequeLeaf: "",
      });
    }
  };

  convertBase642 = (bankPassbook) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(bankPassbook);
      fileReader.onload = () => {
        resolve(fileReader.result);
        console.log(fileReader.result);
        localStorage.setItem("file", fileReader.result);
        console.log(localStorage.getItem("file"));
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  bankPassbook = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let bankPassbook = e.target.files[0];
      console.log("bankPassbook" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("bankPassbook" + bankPassbook);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log(bankPassbook.type);
      console.log(bankPassbook);

      // const base64 = this.convertBase641(bankPassbook);

      if (
        bankPassbook.type === "image/png" ||
        bankPassbook.type === "image/jpeg"
      ) {
        this.setState({ bankPassbook: bankPassbook });
        // console.log(
        //   "bankPassbook inside" + JSON.stringify(this.state.bankPassbook)
        // );
      } else if (
        bankPassbook.type !== "image/png" &&
        bankPassbook.type !== "image/jpeg"
      ) {
        // document.getElementById("exampleFormControlFile").value = "";
        // this.setState({ bankPassbook: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        bankPassbook: "",
      });
    }
  };
  handleChanges = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /\S+@[A-Za-z]+\.com/;
    const ks = /\S+@[A-Za-z]+\.co.in/;
    if (!re.test(value) && !ks.test(value)) {
      this.setState({
        emailError: "Invalid email",
      });
    } else {
      this.setState({
        emailError: "",
      });
    }
  };

  ChangeIFSC = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /^[A-Za-z]{4}\d{7}$/;

    if (value.length < 11) {
      this.setState({
        IFSCError: "Please enter the valid IFSC",
      });
    } else {
      this.setState({
        IFSCError: "",
      });
    }
  };

  next(e) {
    e.preventDefault();
    this.setState({ submitted: true });
    console.log("----testing1----");
    const {
      showAdharModal,
      showPersonalModal,
      showFilesModal,
      showButton,
      showBankModal,
      firstName,
      lastName,
      gender,
      email,
      mobileCountryCode,
      mobileNumber,
      qualification,
      specialization,
      experience,
      address,
      city,
      state,
      pincode,
      phoneError,
      emailError,
      // landLineCode,
      // landLineNumber,
    } = this.state;
    if (
      showPersonalModal == true 
      &&
      firstName &&
      lastName &&
      gender &&
      email &&
      mobileCountryCode &&
      mobileNumber &&
      qualification &&
      specialization &&
      experience &&
      address &&
      city &&
      state &&
      pincode &&
      emailError == "" &&
      phoneError == ""
      // landLineCode==""&&
      // landLineNumber==""
    ) {
      this.setState({
        ProgressBarnum: 100,
        showPersonalModal: false,
        showAdharModal: true,
        en6: true,
        showButton: false,
        showNextButton: true,
        en1: true,
      });
    } else if (showAdharModal == true) {
      this.setState({
        ProgressBarnum1: 100,
        showPersonalModal: false,
        showAdharModal: false,
        showFilesModal: true,
        showButton: false,
        showNextButton: false,
        showNextButton1: true,

        en2: true,
      });
    }
    // } else if (
    //   showFilesModal == true
    //   // panCardNumber &&
    //   // aadharCardError &&
    //   // experienceCertificate &&
    //   // addressProof
    // ) {
    //   this.setState({
    //     ProgressBarnum2: 100,
    //     showPersonalModal: false,
    //     showAdharModal: false,
    //     showFilesModal: false,
    //     showBankModal: true,
    //     showButton: true,
    //     showNextButton: false,
    //     en3: true,
    //   });
    // } else if (showBankModal == true) {
    //   this.setState({ showButton: true, en6: false });
    // }
  }

  next1 = (e) => {
    e.preventDefault();
    // console.log("submitted1" + this.state.submitted1);
    this.setState({ submitted1: true });
    const {
      panCardNumber,
      aadharCard,
      file,
      experienceCertificate,
      addressProof,
      showFilesModal,
      showBankModal,
      panError,
      submitted1,
    } = this.state;
    if (
      showFilesModal == true &&
      aadharCard &&
      experienceCertificate &&
      addressProof &&
      panCardNumber &&
      panError == ""
    ) {
      this.setState({
        ProgressBarnum2: 100,
        showPersonalModal: false,
        showAdharModal: false,
        showFilesModal: false,
        showBankModal: true,
        showButton: true,
        showNextButton: false,
        showNextButton1: false,
        en3: true,
      });
    } else if (showBankModal == true) {
      this.setState({ showButton: true, en6: false });
    }
  };
  handleSubmit(e) {
    e.preventDefault();
    this.setState({ submitted12: true });
    const {
      firstName,
      lastName,
      gender,
      email,
      mobileCountryCode,
      mobileNumber,
      qualification,
      specialization,
      experience,
      address,
      city,
      state,
      pincode,
      aadharNumber,
      panCardNumber,
      aadharCard,
      experienceCertificate,
      addressProof,
      BankName,
      branchName,
      AccountNumber,
      ifscCode,
      swiftCode,
      cancelledChequeLeaf,
      panError,
      IFSCError,
      phoneError,
      emailError,
      country,
      bankPassbook,
      landLineCode,
      landLineNumber,
    } = this.state;

    if (
      // this.state.submitted12=== true
      // firstName &&
      // lastName &&
      // gender &&
      // email &&
      // mobileCountryCode &&
      // mobileNumber &&
      // qualification &&
      // specialization &&
      // experience &&
      // address &&
      // city &&
      // state &&
      // pincode &&
      // aadharNumber &&
      // panCardNumber &&
      // aadharCard &&
      // experienceCertificate &&
      // addressProof &&
       // country &&
      BankName &&
      branchName &&
      AccountNumber &&
      ifscCode &&
      swiftCode &&     
      cancelledChequeLeaf &&
      // panError == "" &&
      IFSCError == "" &&
      // phoneError == "" &&
      // emailError == "" &&
      bankPassbook 
      // landLineCode== "" &&
      // landLineNumber== ""
    ) {
      console.log(this.state.cancelledChequeLeaf);
      const formData = new FormData();
      formData.append("firstName", firstName);
      formData.append("lastName", lastName);
      formData.append("gender", gender);
      formData.append("email", email);
      formData.append("mobileCountryCode", mobileCountryCode);
      formData.append("mobileNumber", mobileNumber);
      formData.append("qualification", qualification);
      formData.append("specialization", specialization);
      formData.append("experience", experience);
      formData.append("address", address);
      formData.append("city", city);
      formData.append("country", country);
      formData.append("state", state);
      formData.append("pincode", pincode);
      formData.append("aadharNumber", aadharNumber);
      formData.append("panCardNumber", panCardNumber);
      formData.append("aadharCard", aadharCard);
      formData.append("experienceCertificate", experienceCertificate);
      formData.append("addressProof", addressProof);
      formData.append("BankName", BankName);
      formData.append("branchName", branchName);
      formData.append("AccountNumber", AccountNumber);
      formData.append("ifscCode", ifscCode);
      formData.append("swiftCode", swiftCode);
      formData.append("cancelledChequeLeaf", cancelledChequeLeaf);
      formData.append("bankPassbook", bankPassbook);

      this.props.submitselfemp(formData);
      console.log("=======formData========" + JSON.stringify(formData));

      // Swal.fire({
      //   text: "Your Application in process",
      //   confirmButtonColor: "#3085d6",
      //   confirmButtonText: "ok ",
      // });
    }
  }
  back(e) {
    e.preventDefault();
    const { showAdharModal, showPersonalModal, showFilesModal, showBankModal } =
      this.state;
    if (showBankModal == true) {
      this.setState({
        ProgressBarnum2: 0,
        showPersonalModal: false,
        showAdharModal: false,
        showFilesModal: true,
        showBankModal: false,
        en6: false,
        showButton: false,
        showNextButton1: true,
        showNextButton: false,
      });
    } else if (showFilesModal == true) {
      this.setState({
        ProgressBarnum1: 0,
        showPersonalModal: false,
        showAdharModal: true,
        showFilesModal: false,
        en6: false,
        showButton: false,
        showNextButton: true,
        showNextButton1: false,
      });
    } else if (showAdharModal == true) {
      this.setState({
        ProgressBarnum: 0,
        showPersonalModal: true,
        showAdharModal: false,
        showFilesModal: false,
        en6: false,
        showButton: false,
        showNextButton: true,
      });
    }
  }
  componentDidMount() {

  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    if (this.props.isSelfSuccess !== prevProps.isSelfSuccess) {
      if (
        this.state.submitted12 &&
        this.props.isSelfSuccess &&
        this.props.isSelfSuccess.success
      ) {
        this.setState({ showOtpModal: true,  });
      } else if (this.state.submitted12 && !this.props.isSelfSuccess.success) {
       
        Swal.fire({
          title: "",
          text: this.props.isSelfSuccess.message,
          icon: "info",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
        this.setState({ showOtpModal: false });
      }
    }
    if (this.props.isAadharSuccess !== prevProps.isAadharSuccess) {
      if (
        this.state.submittedVerify &&
        this.props.isAadharSuccess &&
        this.props.isAadharSuccess.data===true
      ) {
        Swal.fire({
          title: "",
          text: "Aadhar Number verified successfully",
          icon: "info",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
        this.setState({ en6: false, submitLoader: true, });
      } else if (this.state.submittedVerify && 
        this.props.isAadharSuccess&&
        this.props.isAadharSuccess.data===false) {
       
        Swal.fire({
          title: "",
          text: "Please enter valid Aadhar Number",
          icon: "info",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
        this.setState({ en6: true });
        
      }
    }

  }

  render() {
    const {
      firstName,
      lastName,
      gender,
      email,
      mobileCountryCode,
      mobileNumber,
      qualification,
      specialization,
      experience,
      address,
      city,
      state,
      pincode,
      aadharNumber,
      panCardNumber,
      aadharCard,
      experienceCertificate,
      addressProof,
      BankName,
      branchName,
      AccountNumber,
      reEnterAcc,
      ifscCode,
      swiftCode,
      cancelledChequeLeaf,
      submitted,
      submittedVerify,
      submitLoader,
      submitted1,
      submitted12,
      file,
      panError,
      bankPassbook,
      landLineCode,
      landLineNumber,
      country,

    } = this.state;
    return (
      <div className="page-container " style={{ paddingLeft: "0px" }}>
        <div
          className="header navbar"
          // style={{ width: "100%", position: "absolute" }}
        >
          <div className="header-container">
            <ul className="nav-left">
              <li>
                <img src={Logo} alt="CtrlSwift" style={{ width: "50%" }} />
              </li>
            </ul>
          </div>
        </div>

        <Container>
          <div className="heading-self">
            <h2 style={{ color: "#4b5050" }}>SELF EMPLOYED REGISTRATION</h2>
          </div>
          <Row className="mt-20">
            <Col md="sm">
              <Button className="probutton" disabled={this.state.en1}>
                1
              </Button>
            </Col>
            <Col style={{ marginTop: 15 }}>
              <ProgressBar
                style={{ height: "10%" }}
                now={this.state.ProgressBarnum}
              />
            </Col>
            <Col md="sm">
              <Button className="probutton" disabled={this.state.en2}>
                2
              </Button>
            </Col>
            <Col style={{ marginTop: 15 }}>
              <ProgressBar
                style={{ height: "10%" }}
                now={this.state.ProgressBarnum1}
              />
            </Col>
            <Col md="sm">
              <Button className="probutton" disabled={this.state.en3}>
                3
              </Button>
            </Col>
            <Col style={{ marginTop: 15 }}>
              <ProgressBar
                style={{ height: "10%" }}
                now={this.state.ProgressBarnum2}
              />
            </Col>
            <Col md="sm">
              <Button className="probutton" disabled={this.state.en4}>
                4
              </Button>
            </Col>
          </Row>
          <Row className="mt-10">
            <Col className="c1">Personal Details</Col>
            <Col className="c2">Aadhar Card Verification</Col>
            <Col className="c3">Files Upload</Col>
            <Col className="c4">Bank Details</Col>
          </Row>
          {/* ----------------------personal Details------------------------ */}
          {this.state.showPersonalModal == true ? (
            <Container>
              <Form onSubmit={this.next}>
                <h4>
                  <Form.Label className="heading1-self">
                    Personal Details
                  </Form.Label>
                </h4>

                <Form.Row>
                  <Form.Group as={Col} md="4" controlId="firstName">
                    <Form.Label>First Name</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="firstName"
                      value={firstName}
                      onChange={this.handleChange}
                      id="seFirstname"
                    />
                    {submitted && !firstName && (
                      <div className="validationError">
                        First Name is required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="lastName">
                    <Form.Label>Last Name</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="lastName"
                      value={lastName}
                      onChange={this.handleChange}
                      id="seLastname"
                    />
                    {submitted && !lastName && (
                      <div className="validationError">
                        Last nameis required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="gender">
                    <Form.Label>Gender</Form.Label>
                    <select
                      type="dropdown"
                      autoComplete="off"
                      className="form-control"
                      name="gender"
                      value={gender}
                      onChange={this.handleChange}
                      id="seGender"
                    >
                      <option value=""></option>
                      <option value="female">Female</option>
                      <option value="male">Male</option>
                      <option value="male">Transgender</option>
                      <option value="male">others</option>
                    </select>
                    {submitted && !gender && (
                      <div className="validationError">Gender is required</div>
                    )}
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md="4" controlId="email">
                    <Form.Label>Email</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="email"
                      value={email}
                      onChange={this.handleChanges}
                      id="seEmail"
                    />
                    {submitted && !email && (
                      <div className="validationError">Email is required</div>
                    )}

                    {this.state.emailError !== "" && submitted && email && (
                      <div className="validationError">
                        {this.state.emailError}
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="mobileCountryCode">
                    <Form.Label>Mobile Country Code </Form.Label>
                    <select
                      type="dropdown"
                      className="form-control"
                      name="mobileCountryCode"
                      value={mobileCountryCode}
                      placeholder="select"
                      onChange={this.handleChange}
                      id="seMobCountrycode"
                    >
                      <option value=""></option>

                      <option value="+91">+91</option>
                      <option value="+1">+1</option>
                      <option value="+86">+86</option>
                      <option value="+44">+44</option>
                      <option value="+81">+81</option>
                      <option value="+49">+49</option>
                      <option value="+33">+33</option>
                      <option value="+55">+55</option>
                      <option value="+39">+39</option>
                      <option value="+1">+1</option>
                      <option value="+7">+7</option>
                      <option value="+65">+65</option>
                      <option value="+64">+64</option>
                      <option value="+61">+61</option>
                      <option value="+964">+964</option>
                    </select>
                    {submitted && !mobileCountryCode && (
                      <div className="validationError">
                        Country Code is required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="mobileNumber">
                    <Form.Label>mobileNumber</Form.Label>
                    <input
                      type="number"
                      autoComplete="off"
                      className="form-control"
                      name="mobileNumber"
                      value={mobileNumber}
                      onChange={this.handlePhoneChange}
                      id="semobileNumber"
                      format="##########"
                    />
                    {submitted && !mobileNumber && (
                      <div className="validationError">
                        mobileNumber is required
                      </div>
                    )}
                    {submitted &&
                      this.state.phoneError != "" &&
                      mobileNumber && (
                        <div className="validationError">
                          {this.state.phoneError}
                        </div>
                      )}
                  </Form.Group>
                </Form.Row>
                <Form.Row>                
                <Form.Group as={Col} md="4" controlId="landLineCode">
                    <Form.Label>landLineCode</Form.Label>
                    <input
                      type="number"
                      autoComplete="off"
                      className="form-control"
                      name="landLineCode"
                      value={landLineCode}
                      onChange={this.handleChange}
                      id="selandLineCode"
                    />
                    {submitted && !landLineCode && (
                      <div className="validationError">
                        landLineCode is required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="landLineNumber">
                    <Form.Label>landLineNumber</Form.Label>
                    <input
                      type="number"
                      autoComplete="off"
                      className="form-control"
                      name="landLineNumber"
                      value={landLineNumber}
                      onChange={this.handleChange}
                      id="selandLineNumber"
                    />
                    {submitted && !landLineNumber && (
                      <div className="validationError">
                        landLineNumber is required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="qualification">
                    <Form.Label>Qualification</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="qualification"
                      value={qualification}
                      onChange={this.handleChange}
                      id="seQualification"
                    />
                    {submitted && !qualification && (
                      <div className="validationError">
                        Qualification is required
                      </div>
                    )}
                  </Form.Group>
                  </Form.Row>
                <Form.Row>
                 
                  <Form.Group as={Col} md="4" controlId="specialization">
                    <Form.Label>Specialization</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="specialization"
                      value={specialization}
                      onChange={this.handleChange}
                      id="seSpecialization"
                    />
                    {submitted && !specialization && (
                      <div className="validationError">
                        Specialization is required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="experience">
                    <Form.Label>Experience</Form.Label>
                    <input
                      type="number"
                      autoComplete="off"
                      className="form-control"
                      name="experience"
                      value={experience}
                      onChange={this.handleChange}
                      id="seExperience"
                    />
                    {submitted && !experience && (
                      <div className="validationError">
                        Experience is required
                      </div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="country">
                    <Form.Label>Country</Form.Label>
                    {/* <Form.Control type="text" placeholder="India" value="India"  disabled /> */}
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="country"
                      value={country}
                      onChange={this.handleChange}
                      id="secountry"
                    />
                    {submitted && !country && (
                      <div className="validationError">country is required</div>
                    )}
                  </Form.Group>

                </Form.Row>
                <Form.Row>
                <Form.Group as={Col} md="4" controlId="state">
                    <Form.Label>state</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="state"
                      value={state}
                      onChange={this.handleChange}
                      id="seState"
                    />
                    {submitted && !state && (
                      <div className="validationError">State is required</div>
                    )}
                  </Form.Group>
                 
                  <Form.Group as={Col} md="4" controlId="city">
                    <Form.Label>City</Form.Label>
                    <input
                      type="text"
                      autoComplete="off"
                      className="form-control"
                      name="city"
                      value={city}
                      onChange={this.handleChange}
                      id="seCity"
                    />
                    {submitted && !city && (
                      <div className="validationError">City is required</div>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} md="4" controlId="address">
                    <Form.Label>Address </Form.Label>
                    <textarea
                      className="form-control"
                      name="address"
                      value={address}
                      onChange={this.handleChange}
                      id="seAddress"
                    />
                    {submitted && !address && (
                      <div className="validationError">Address is required</div>
                    )}
                  </Form.Group>
                </Form.Row>
                <Form.Row></Form.Row>
                <Form.Row>
                 

                  <Form.Group as={Col} md="4" controlId="pincode">
                    <Form.Label>Pincode</Form.Label>
                    <input
                      type="number"
                      autoComplete="off"
                      className="form-control"
                      name="pincode"
                      value={pincode}
                      onChange={this.handleChange}
                      id="sePincode"
                    />

                    {submitted && !pincode && (
                      <div className="validationError">Pincode is required</div>
                    )}
                  </Form.Group>
                </Form.Row>
              </Form>
            </Container>
          ) : null}
          {/* ----------------------Adhar verification------------------------ */}
          {this.state.showAdharModal == true ? (
            <Form onSubmit={this.next}>
              <h4>
                <Form.Label className="heading1-self">
                  Aadhar Card Verification
                </Form.Label>
              </h4>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="pincode">
                  <Form.Label>Aadhar Number</Form.Label>
                  <Row>
                    <Col md="7">
                      <input
                        type="number"
                        autoComplete="off"
                        className="form-control"
                        name="aadharNumber"
                        value={aadharNumber}
                        onChange={this.handleAadharChange}
                        id="seAdharNumber"
                        format="#### #### ####"
                        // mask="#"
                      />
                      {submittedVerify && !aadharNumber && (
                        <div className="validationError">
                          Aadhar Number is required
                        </div>
                      )}
                      {submittedVerify &&
                        this.state.aadharError !== "" &&
                        aadharNumber && (
                          <div className="validationError">
                            {this.state.aadharError}
                          </div>
                        )}
                    </Col>
                    <Col>
                      <Button
                        size="sm"
                        onClick={this.handleSubmit1}
                        style={{ marginTop: "7px" }}
                      >
                        Verify
                      </Button>
                      {submitLoader == true ? (
                        <Page
                          loader={"bubble-spin"}
                          color={"#A9A9A9"}
                          size={10}
                        />
                      ) : null}
                    </Col>
                  </Row>
                </Form.Group>
              </Form.Row>

              {/* <Form.Row>
                    <Form.Group>
                   
                      <Button size="sm"
                      onClick={this.handleSubmit1}
                      >Verify</Button>
                      {submitLoader==true? <Page loader={"bubble-spin"} color={"#A9A9A9"} size={10} />:null}
                    </Form.Group>
                    </Form.Row> */}
            </Form>
          ) : null}

          {/* ------------------files upload---------------------------      */}
          {this.state.showFilesModal == true ? (
            <Form onSubmit={this.next1}>
              <h4>
                <Form.Label className="heading1-self">File Upload</Form.Label>
              </h4>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="experience">
                  <Form.Label>Pan Card Number</Form.Label>

                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="panCardNumber"
                    value={panCardNumber}
                    onChange={this.handlePanChange}
                    id="sepanCardNumber"
                  />
                  {submitted1 && !panCardNumber && (
                    <div className="validationError">Pan Card is required</div>
                  )}

                  {submitted1 && this.state.panError !== "" && panCardNumber && (
                    <div className="validationError">{this.state.panError}</div>
                  )}
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="country">
                  <Form.Label>Aadhar Card</Form.Label>
                  <InputGroup>
                    <Button className="btn btn-primary btn-color-admin">
                      Upload
                      <input
                        type="file"
                        autoComplete="off"
                        className="btn btn-primary btn-color-admin file-upload-css"
                        name="aadharCard"
                        accept="image/png, image/jpeg"
                        onChange={(e) => this.aadharCard(e)}
                      />
                    </Button>
                    <FormControl
                      placeholder={this.state.aadharCard.name}
                      disabled
                    />
                  </InputGroup>

                  {submitted1 && !aadharCard && (
                    <div className="validationError">
                      Aadhar Card is required
                    </div>
                  )}
                </Form.Group>
              </Form.Row>

              <Form.Row>
                <Form.Group as={Col} md="4">
                  <Form.Label>Experience certificate </Form.Label>
                  <InputGroup>
                    <Button className="btn btn-primary btn-color-admin">
                      Upload
                      <input
                        type="file"
                        autoComplete="off"
                        className="btn btn-primary btn-color-admin file-upload-css"
                        name="experienceCertificate"
                        accept="image/png, image/jpeg"
                        onChange={(e) => this.experienceCertificate(e)}
                      />
                    </Button>
                    <FormControl
                      placeholder={this.state.experienceCertificate.name}
                      disabled
                    />
                  </InputGroup>

                  {submitted1 && !experienceCertificate && (
                    <div className="validationError">
                      Certificate is required
                    </div>
                  )}
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md="4">
                  <Form.Label>Address Proof</Form.Label>
                  <InputGroup>
                    <Button className="btn btn-primary btn-color-admin ">
                      Upload
                      <input
                        type="file"
                        autoComplete="off"
                        className="btn btn-primary btn-color-admin file-upload-css"
                        name="addressProof"
                        accept="image/png, image/jpeg"
                        onChange={(e) => this.addressProof(e)}
                      />
                    </Button>
                    <FormControl
                      placeholder={this.state.addressProof.name}
                      disabled
                    />
                  </InputGroup>
                  {submitted1 && !addressProof && (
                    <div className="validationError">
                      Address Proof is required
                    </div>
                  )}
                </Form.Group>
              </Form.Row>
            </Form>
          ) : null}
          {/* -----------------------Bandk Details-------------------------- */}
          {this.state.showBankModal == true ? (
            <Form>
              <h4>
                <Form.Label className="heading1-self">Bank Details</Form.Label>
              </h4>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="experience">
                  <Form.Label>Bank Name</Form.Label>
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="BankName"
                    value={BankName}
                    onChange={this.handleChange}
                    id="seBankName"
                  />
                  {submitted12 && !BankName && (
                    <div className="validationError">Bank Name is required</div>
                  )}
                </Form.Group>
                <Form.Group as={Col} md="4" controlId="country">
                  <Form.Label>Branch Name</Form.Label>
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="branchName"
                    value={branchName}
                    onChange={this.handleChange}
                    id="sBranchName"
                  />
                  {submitted12 && !branchName && (
                    <div className="validationError">
                      Branch name is required
                    </div>
                  )}
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="experience">
                  <Form.Label> Account number</Form.Label>
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="AccountNumber"
                    value={AccountNumber}
                    onChange={this.handleChange}
                    id="seAccountNumber"
                  />
                  {submitted12 && !AccountNumber && (
                    <div className="validationError">
                      Account Number is required
                    </div>
                  )}
                </Form.Group>
                <Form.Group as={Col} md="4" controlId="country">
                  <Form.Label>Re-enter Account number</Form.Label>
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="reEnterAcc"
                    value={reEnterAcc}
                    onChange={this.handleChange}
                    id="seReEnter"
                  />
                  {submitted12 && !reEnterAcc && (
                    <div className="validationError">
                      Account Number is required
                    </div>
                  )}
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="experience">
                  <Form.Label> IFSC Code</Form.Label>
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="ifscCode"
                    value={ifscCode}
                    onChange={this.ChangeIFSC}
                    id="seIfsc"
                  />
                  {submitted12 && !ifscCode && (
                    <div className="validationError">IFSC Code is required</div>
                  )}

                  {submitted12 && this.state.IFSCError !== "" && ifscCode && (
                    <div className="validationError">
                      {this.state.IFSCError}
                    </div>
                  )}
                </Form.Group>
                <Form.Group as={Col} md="4" controlId="country">
                  <Form.Label>Swift Code</Form.Label>
                  <input
                    type="text"
                    autoComplete="off"
                    className="form-control"
                    name="swiftCode"
                    value={swiftCode}
                    onChange={this.handleChange}
                    id="seSwift"
                  />
                  {submitted12 && !swiftCode && (
                    <div className="validationError">
                      Swift Code is required
                    </div>
                  )}
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md="4" controlId="country">
                  <Form.Label>Cheque leaf</Form.Label>
                  <InputGroup>
                    <Button className="btn btn-primary btn-color-admin">
                      Upload
                      <input
                        type="file"
                        autoComplete="off"
                        className="form-control"
                        name="cancelledChequeLeaf"
                        // value={cancelledChequeLeaf}
                        onChange={(e) => this.cancelledChequeLeaf(e)}
                        accept="image/png, image/jpeg"
                        // id="seCheque"
                        style={{
                          position: "absolute",
                          fontSize: "50px",
                          opacity: "0",
                          right: "0",
                          top: "0",
                        }}
                      />
                    </Button>
                    <FormControl
                      placeholder={this.state.cancelledChequeLeaf.name}
                      disabled
                    />
                  </InputGroup>
                  {submitted12 && !cancelledChequeLeaf && (
                    <div className="validationError">Cheque is required</div>
                  )}
                </Form.Group>

                <Form.Group as={Col} md="4" controlId="country">
                  <Form.Label>Bank Passbook</Form.Label>
                  <InputGroup>
                    <Button className="btn btn-primary btn-color-admin">
                      Upload
                      <input
                        type="file"
                        autoComplete="off"
                        className="form-control"
                        name="bankPassbook"
                        // value={cancelledChequeLeaf}
                        onChange={(e) => this.bankPassbook(e)}
                        accept="image/png, image/jpeg"
                        // id="seCheque"
                        style={{
                          position: "absolute",
                          fontSize: "50px",
                          opacity: "0",
                          right: "0",
                          top: "0",
                        }}
                      />
                    </Button>
                    <FormControl
                      placeholder={this.state.bankPassbook.name}
                      disabled
                    />
                  </InputGroup>
                  {submitted12 && !this.bankPassbook && (
                    <div className="validationError">Cheque is required</div>
                  )}
                </Form.Group>
              </Form.Row>
            </Form>
          ) : null}

          <Form.Row>
            <Form.Group as={Col} md="2" style={{ align: "center" }}>
              <Button
                className="btn btn-primary btn-color-admin"
                onClick={this.back}
                size="md"
                // style={{marginLeft:"40em"}}
                id="seback"
              >
                Back
              </Button>
            </Form.Group>
            <Form.Group as={Col} md="2" style={{ align: "center" }}>
              {this.state.showNextButton ? (
                <Button
                  className="btn btn-primary btn-color-admin"
                  id="senext"
                  onClick={this.next}
                  disabled={this.state.en6}
                  size="md"
                  // style={{ marginLeft:"40em"}}
                >
                  Next
                </Button>
              ) : null}
            </Form.Group>
            <Form.Group as={Col} md="2" style={{ align: "center" }}>
              {this.state.showNextButton1 ? (
                <Button
                  className="btn btn-primary btn-color-admin"
                  id="senext"
                  onClick={this.next1}
                  // disabled={this.state.en6}
                  size="md"
                  // style={{ marginLeft:"40em"}}
                >
                  Next
                </Button>
              ) : null}
            </Form.Group>
            </Form.Row>
            <Form.Row>
            <Form.Group as={Col} md="2" style={{ align: "center" }}>
              {this.state.showButton ? (
                <Button
                  className="btn btn-primary btn-color-admin"
                  id="seSubmit"
                  style={{ marginLeft: "30em" }}
                  onClick={this.handleSubmit}
                >
                  submit{" "}
                </Button>
              ) : null}
            </Form.Group>
          </Form.Row>
        </Container>
      </div>
    );
  }
}

selfEmployedReg.propTypes = {
  submitselfemp: PropTypes.func,
  verifyAadharNumber: PropTypes.func,
};
const mapStateToProps = (state) => {
  return {
    isSelfSuccess: state.selfempRegisterReducer.isSelfSuccess,
    isAadharSuccess: state.selfempRegisterReducer.isAadharSuccess,
  };
};

const mapDispatchToProps = (dispatch) => ({
  submitselfemp: (data) => dispatch(submitselfemp(data)),
  verifyAadharNumber: (aadharNumber) => dispatch(verifyAadharNumber(aadharNumber)),
});

export default connect(mapStateToProps, mapDispatchToProps)(selfEmployedReg);
