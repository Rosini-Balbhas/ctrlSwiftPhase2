// import * as Constants from "../constants";
// import { any } from "prop-types";
// export default (state = {}, { isDetailSuccess = any, type }) => {
//   switch (type) {
//     case Constants.ADD_EMPLOYEE_RESPONSE: {
//       console.log(
//         "========in reducer=======" + JSON.stringify(isDetailSuccess)
//       );
//       const statenew = { ...state };
//       statenew.isDetailSuccess = isDetailSuccess;

//       return statenew;
//     }
//     default:
//       return state;
//   }
// };
