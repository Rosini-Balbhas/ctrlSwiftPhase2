import React from "react";
import { Form, Col, Row, Container, Button } from "react-bootstrap";
// import onboard from "../images/onboard.jpg";
import Sidemenu from "../components/Sidemenu3";
import Header1 from "../components/header1";
import Footer from "../components/footer";
import { PropTypes } from "prop-types";
import { connect } from "react-redux";
import Swal from "sweetalert2";

import { addUser } from "./action";

class onboardingEngineer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employeeId: "",
      partnerId: "",
      firstName: "",
      lastName: "",
      gender: "",
      email: "",
      mobileCountryCode: "",
      mobile: "",
      qualification: "",
      specialization: "",
      experience: "",
      country: "",
      address: "",
      city: "",
      stateName: "",
      pincode: "",
      idProof: "",
      addressProof: "",
      panCard: "",
      aadharCard: "",
      emailError: "",
      phoneError: "",

      submitted: false,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handlePhoneChange = this.handlePhoneChange.bind(this);
  }
  navigate = (url) => {
    this.props.history.push(url);
  };
  handleChanges = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
    const re = /\S+@[A-Za-z]+\.com/;
    const ks = /\S+@[A-Za-z]+\.co.in/;
    if (!re.test(value) && !ks.test(value)) {
      this.setState({
        emailError: "Invalid email",
      });
    } else {
      this.setState({
        emailError: "",
      });
    }
  };
  handlePhoneChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });
    const number = /^(?:(?:\\+|0{0,2})91(\s*[\\-]\s*)?|[0]?)?[789]\d{9}$/;
    if (value.length > 10) {
      this.setState({ phoneError: "Invalid Phone number" });
    } else {
      this.setState({
        phoneError: "",
      });
    }
  };

  handleChange = (event) => {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
  };

  file = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let addressProof = e.target.files[0];
      console.log("addressProof" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("addressProof" + addressProof);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log(addressProof.type);
      console.log(addressProof);

      // const base64 = this.convertBase641(addressProof);

      if (
        addressProof.type === "image/png" ||
        addressProof.type === "image/jpeg"
      ) {
        this.setState({ addressProof: addressProof });
        // console.log(
        //   "addressProof inside" + JSON.stringify(this.state.addressProof)
        // );
      } else if (
        addressProof.type !== "image/png" &&
        addressProof.type !== "image/jpeg"
      ) {
        document.getElementById("exampleFormControlFile").value = "";
        this.setState({ addressProof: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        addressProof: "",
      });
    }
  };

  file1 = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let panCard = e.target.files[0];
      console.log("panCard" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("panCard" + panCard);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log(panCard.type);
      console.log(panCard);

      // const base64 = this.convertBase641(panCard);

      if (panCard.type === "image/png" || panCard.type === "image/jpeg") {
        this.setState({ panCard: panCard });
        // console.log(
        //   "panCard inside" + JSON.stringify(this.state.panCard)
        // );
      } else if (
        panCard.type !== "image/png" &&
        panCard.type !== "image/jpeg"
      ) {
        document.getElementById("exampleFormControlFile1").value = "";
        this.setState({ panCard: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        panCard: "",
      });
    }
  };

  file2 = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let aadharCard = e.target.files[0];
      console.log("file" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log("file" + aadharCard);
      // const base64 = this.convertBase642(aadharCard);

      console.log(aadharCard.type);
      if (aadharCard.type === "image/png" || aadharCard.type === "image/jpeg") {
        this.setState({ aadharCard: aadharCard });
      } else if (
        aadharCard.type !== "image/png" &&
        aadharCard.type !== "image/jpeg"
      ) {
        document.getElementById("exampleFormControlFile2").value = "";
        this.setState({ aadharCard: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        aadharCard: "",
      });
    }
  };

  file3 = (e) => {
    if (e.target.files[0] !== undefined && e.target.files[0] !== null) {
      let idProof = e.target.files[0];
      console.log("idProof" + e.target.files[0]);
      console.log(this.statebase64);
      console.log("idProof" + idProof);
      console.log("fsize" + JSON.stringify(e.target.files[0]));
      console.log(idProof.type);
      console.log(idProof);

      // const base64 = this.convertBase641(idProof);

      if (idProof.type === "image/png" || idProof.type === "image/jpeg") {
        this.setState({ idProof: idProof });
        // console.log(
        //   "idProof inside" + JSON.stringify(this.state.idProof)
        // );
      } else if (
        idProof.type !== "image/png" &&
        idProof.type !== "image/jpeg"
      ) {
        document.getElementById("exampleFormControlFile").value = "";
        this.setState({ idProof: "" });
        Swal.fire({
          title: "",
          text: "Only .jpeg or .png is Accepted",
          icon: "warning",
          showCancelButton: false,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "OK",
        });
      }
    } else {
      this.setState({
        idProof: "",
      });
    }
  };

  handleSubmit(e) {
    e.preventDefault();
    this.setState({ submitted: true });
    const {
      employeeId,
      partnerId,
      firstName,
      lastName,
      gender,
      email,
      mobile,
      mobileCountryCode,
      qualification,
      specialization,
      experience,
      country,
      address,
      city,
      stateName,
      pincode,
      idProof,
      addressProof,
      panCard,
      aadharCard,
      emailError,
      phoneError,
    } = this.state;
    if (
      employeeId &&
      partnerId &&
      firstName &&
      lastName &&
      gender &&
      email &&
      mobile &&
      mobileCountryCode &&
      qualification &&
      specialization &&
      experience &&
      country &&
      address &&
      city &&
      stateName &&
      pincode &&
      idProof &&
      addressProof &&
      panCard &&
      aadharCard &&
      emailError == "" &&
      phoneError == ""
    ) {
      this.props.addUser(
        employeeId && partnerId,
        firstName,
        lastName,
        gender,
        email,
        mobile,
        mobileCountryCode,
        qualification,
        specialization,
        experience,
        country,
        address,
        city,
        stateName,
        pincode,
        idProof,
        addressProof,
        panCard,
        aadharCard
      );
    }
  }
  navigate = (url) => {
    this.props.history.push(url);
  };

  render() {
    const {
      partnerId,
      submitted,
      employeeId,
      firstName,
      lastName,
      gender,
      email,
      mobile,
      mobileCountryCode,
      qualification,
      specialization,
      experience,
      country,
      address,
      city,
      stateName,
      pincode,
      idProof,
      addressProof,
      panCard,
      aadharCard,
      emailError,
    } = this.state;
    return (
      <div className="page-container" style={{ paddingLeft: "0px" }}>
        <Header1 navigate={(url) => this.navigate("/partnerLogin")} />
        <main className="main-content bgc-grey-100">
          <div id="mainContent">
            <div className="row">
              <Sidemenu
                navigate={(url) => this.navigate(url)}
                selected="onBoardingEngineer"
                className="sidemenu2"
              />
              <div className="col ">
                <Container>
                  <Row>
                    <Col>
                      <p style={{ fontSize: 26, color: "black" }}>
                        Add/Edit Employee
                      </p>
                    </Col>
                  </Row>
                  <Form onSubmit={this.handleSubmit}>
                    <Form.Row>
                      <Form.Group as={Col} md="3" controlId="employeeId">
                        <Form.Label>Employee ID*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="employeeId"
                          value={employeeId}
                          onChange={this.handleChange}
                        />
                        {submitted && !employeeId && (
                          <div className="validationError">
                            Employee ID is required
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md="3" controlId="firstName">
                        <Form.Label>First Name*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="firstName"
                          value={firstName}
                          onChange={this.handleChange}
                        />
                        {submitted && !firstName && (
                          <div className="validationError">
                            First Name is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3" controlId="lastName">
                        <Form.Label>Last Name*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="lastName"
                          value={lastName}
                          onChange={this.handleChange}
                        />
                        {submitted && !lastName && (
                          <div className="validationError">
                            Last Name is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3" controlId="gender">
                        <Form.Label>Gender*</Form.Label>
                        <select
                          type="dropdown"
                          autoComplete="off"
                          className="form-control"
                          name="gender"
                          value={gender}
                          onChange={this.handleChange}
                        >
                          <option value=""></option>
                          <option value="female">Female</option>
                          <option value="male">Male</option>
                        </select>
                        {submitted && !gender && (
                          <div className="validationError">
                            Gender is required
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md="3" controlId="email">
                        <Form.Label>Email*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="email"
                          value={email}
                          onChange={this.handleChanges}
                        />
                        {submitted && !email && (
                          <div className="validationError">
                            Email is required
                          </div>
                        )}
                        {this.state.emailError !== "" && submitted && email && (
                          <div className="validationError">
                            {this.state.emailError}
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group as={Col} md="3" controlId="mobileCountryCode">
                        <Form.Label>Mobile Country Code *</Form.Label>
                        <select
                          type="dropdown"
                          className="form-control"
                          name="mobileCountryCode"
                          value={mobileCountryCode}
                          placeholder="select"
                          onChange={this.handleChange}
                        >
                          <option value=""></option>

                          <option value="+91">+91</option>
                          <option value="+1">+1</option>
                          <option value="+86">+86</option>
                          <option value="+44">+44</option>
                          <option value="+81">+81</option>
                          <option value="+49">+49</option>
                          <option value="+33">+33</option>
                          <option value="+55">+55</option>
                          <option value="+39">+39</option>
                          <option value="+1">+1</option>
                          <option value="+7">+7</option>
                          <option value="+65">+65</option>
                          <option value="+64">+64</option>
                          <option value="+61">+61</option>
                          <option value="+964">+964</option>
                        </select>
                        {submitted && !mobileCountryCode && (
                          <div className="validationError">
                            Mobile Country Code is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3" controlId="mobile">
                        <Form.Label>Mobile*</Form.Label>
                        <input
                          type="number"
                          autoComplete="off"
                          className="form-control"
                          name="mobile"
                          value={mobile}
                          onChange={this.handlePhoneChange}
                        />
                        {submitted && !mobile && (
                          <div className="validationError">
                            mobile number required
                          </div>
                        )}
                        {submitted && this.state.phoneError != "" && mobile && (
                          <div className="validationError">
                            {this.state.phoneError}
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md="3" controlId="qualification">
                        <Form.Label>Qualification*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="qualification"
                          value={qualification}
                          onChange={this.handleChange}
                        />
                        {submitted && !qualification && (
                          <div className="validationError">
                            Qualification is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3" controlId="specialization">
                        <Form.Label>Specialization*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="specialization"
                          value={specialization}
                          onChange={this.handleChange}
                        />
                        {submitted && !specialization && (
                          <div className="validationError">
                            Specialization is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3" controlId="experience">
                        <Form.Label>Experience*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="experience"
                          value={experience}
                          onChange={this.handleChange}
                        />
                        {submitted && !experience && (
                          <div className="validationError">
                            Experience is required
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md="3" controlId="country">
                        <Form.Label>Country*</Form.Label>
                        <select
                          type="dropdown"
                          className="form-control"
                          name="country"
                          placeholder="select"
                          name="country"
                          value={country}
                          onChange={this.handleChange}
                        >
                          <option value=""></option>
                          <option value="India">India</option>
                          <option value="US">US</option>
                          <option value="China">China</option>
                          <option value="UK">Uk</option>
                          <option value="Japan">Japan</option>
                          <option value="Germany">Germany</option>
                          <option value="France">France</option>
                          <option value="Brazil">Brazil</option>
                          <option value="Italy">Italy</option>
                          <option value="Canada">Canada</option>
                          <option value="Russia">Russia</option>
                          <option value="Singapore">Singapore</option>
                          <option value="New Zealand">New Zealand</option>
                          <option value="Australia">Australia</option>
                          <option value="Iraq">Iraq</option>
                        </select>
                        {submitted && !country && (
                          <div className="validationError">
                            Country is required
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group as={Col} md="3" controlId="address">
                        <Form.Label>Address* </Form.Label>
                        <textarea
                          className="form-control"
                          name="address"
                          value={address}
                          onChange={this.handleChange}
                        />
                        {submitted && !address && (
                          <div className="validationError">
                            Address is required
                          </div>
                        )}
                        {submitted && address && address.length < 4 && (
                          <div className="validationError" className="nav-left">
                            Address is too short, Please provide detailed
                            address
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group as={Col} md="3" controlId="city">
                        <Form.Label>City*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="city"
                          value={city}
                          onChange={this.handleChange}
                        />
                        {submitted && !city && (
                          <div className="validationError">
                            City is required
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md="3" controlId="state">
                        <Form.Label>state*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="stateName"
                          value={stateName}
                          onChange={this.handleChange}
                        />
                        {submitted && !stateName && (
                          <div className="validationError">
                            State is required
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group as={Col} md="3" controlId="pincode">
                        <Form.Label>Pincode*</Form.Label>
                        <input
                          type="text"
                          autoComplete="off"
                          className="form-control"
                          name="pincode"
                          value={pincode}
                          onChange={this.handleChange}
                        />
                        {submitted && !pincode && (
                          <div className="validationError">
                            Pincode is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3" controlId="idProof">
                        <Form.Label>ID proof*</Form.Label>
                        <input
                          type="file"
                          className="form-control"
                          name="idProof"
                          // value={idProof}
                          accept="image/png, image/jpeg"
                          onChange={(e) => this.file3(e)}
                          id="exampleFormControlFile3"
                        />
                        {submitted && !idProof && (
                          <div className="validationError">
                            ID proof is required
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md="3">
                        <Form.Label>Address Proof*</Form.Label>
                        <input
                          type="file"
                          className="form-control"
                          name="addressProof"
                          // value={addressProof}
                          onChange={this.handleChange}
                          accept="image/png, image/jpeg"
                          onChange={(e) => this.file(e)}
                          id="exampleFormControlFile"
                        />
                        {submitted && !addressProof && (
                          <div className="validationError">
                            Address Proof is required
                          </div>
                        )}
                      </Form.Group>

                      <Form.Group as={Col} md="3">
                        <Form.Label>Pan Card*</Form.Label>
                        <input
                          type="file"
                          className="form-control"
                          name="panCard"
                          // value={panCard}
                          onChange={this.handleChange}
                          accept="image/png, image/jpeg"
                          onChange={(e) => this.file1(e)}
                          id="exampleFormControlFile1"
                        />
                        {submitted && !panCard && (
                          <div className="validationError">
                            Pan Card is required
                          </div>
                        )}
                      </Form.Group>
                      <Form.Group as={Col} md="3">
                        <Form.Label>Aadhar card*</Form.Label>
                        <input
                          type="file"
                          className="form-control"
                          autoComplete="off"
                          name="aadharCard"
                          // value={aadharCard}
                          accept="image/png, image/jpeg"
                          onChange={(e) => this.file2(e)}
                          id="exampleFormControlFile2"
                        />
                        {submitted && !aadharCard && (
                          <div className="validationError">
                            Aadhar card is required
                          </div>
                        )}
                      </Form.Group>
                    </Form.Row>

                    <Form.Row>
                      <Form.Group as={Col}></Form.Group>
                      <Form.Group as={Col}></Form.Group>
                      <Form.Group as={Col}>
                        <Button
                          type="submit"
                          className="btn btn-primary"
                          onClick={this.handleSubmit}
                        >
                          Submit
                        </Button>
                      </Form.Group>
                    </Form.Row>
                  </Form>
                </Container>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
}
onboardingEngineer.propTypes = {
  addUser: PropTypes.func,
};
const mapStateToProps = (state) => {
  return {
    // isDetailSuccess: state.addUserreducer.isDetailSuccess,
  };
};
const mapDispatchToProps = (dispatch) => ({
  addUser: (
    employeeId,
    partnerId,
    firstName,
    lastName,
    gender,
    email,
    mobile,
    mobileCountryCode,
    qualification,
    specialization,
    experience,
    country,
    address,
    city,
    stateName,
    pincode,
    idProof,
    addressProof,
    panCard,
    aadharCard
  ) =>
    dispatch(
      addUser(
        employeeId,
        partnerId,
        firstName,
        lastName,
        gender,
        email,
        mobile,
        mobileCountryCode,
        qualification,
        specialization,
        experience,
        country,
        address,
        city,
        stateName,
        pincode,
        idProof,
        addressProof,
        panCard,
        aadharCard
      )
    ),
});

export default connect(mapDispatchToProps, mapStateToProps)(onboardingEngineer);
