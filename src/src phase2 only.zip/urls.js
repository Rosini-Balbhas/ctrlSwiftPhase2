// export const Base_URL = 'http://52.142.34.40:8080/api';
export const Base_URL = "http://52.255.170.184:8008/api";
// export const Base_URL = 'http://52.255.170.184:591/api';
//export const Base_URL = 'https://www.ctrlswift.com/api';
// export const Base_URL = 'http://192.168.149.72:8080/api';

//  export const Base_URL = 'http://13.72.105.179/api';
//export const Base_URL = 'http://localhost:591/api' // VM
//export const Base_URL = 'http://localhost:8080/api' // local API call
//export const Base_URL = `${process.env.REACT_APP_BASE_URL}`;
