import { fork } from "redux-saga/effects";
import userSaga from "./usermanagement/saga";
import adminloginSaga from "./admin_login/saga";
import getmailSaga from "./forgotpassword/getmail/saga";
import forgotOtpSage from "./forgotpassword/validate_otp/saga";
import resetSaga from "./forgotpassword/restpassword/saga";
import requestSaga from "./requests/saga";
import salesAdminLoginSaga from "./sales_login/saga";
import requestDemoSaga from "./requestdemo/saga";
import feedbackSaga from "./feedbacks/saga";
import registrationSaga from "./register/saga";
//import validateOtpSage from './registerotp/saga';
//import registrationpasswordSaga from './registerpassword/saga';
import loginSaga from "./components/header/saga";
// import getmailcustomerSaga from "./forgotpasswordcustomer/getmailcustomer/saga";
// import forgotOtpCustomerSage from './forgotpasswordcustomer/validate_otp_customer/saga';
// import resetCustomerSaga from './forgotpasswordcustomer/resetpasswordcustomer/saga';
import detailsSaga from "./details/saga";
import serviceTaxSaga from "./servicetaxfixation/saga";
import customizePageSaga from "./customize/saga";
import editProfilesaga from "./myAccount/editProfile/saga";
import priceDetailsSaga from "./customize_page2/saga";
import dmasSaga from "./dmsa/saga";
import changePlansaga from "./myAccount/plandetails/saga";
import viewInvoicesaga from "./myAccount/viewInvoice/saga";
import logoutSaga from "./components/header_login/saga";
import dmasAnnexureSaga from "./myAccount/viewDMSA/saga";
//import choosePlanssaga from './myAccount/choosePlans/saga';
import invoiceNumberSaga from "./waiveoffinvoiceid/saga";
import invoiceOtpSaga from "./waiveoffotp/saga";
import taxInvoicesaga from "./myAccount/taxInvoice/saga";
import contactUsSaga from "./contactus/saga";
import invoiceCreateSaga from "./myAccount/invoiceCreate/saga";

//import updateSaga from './editprofileotp/saga';
import upgradeSaga from "./upgrade/saga";
import orderChangeSaga from "./ordersummary/saga";
import reguserSaga from "./registercustomer/saga";
import rateSaga from "./exchangevalue/saga";
import discountSaga from "./discount/saga";
import priceSaga from "./commercialPrice/saga";
import terminateOrderSaga from "./terminationordersummary/saga";
import customerDetailsSaga from "./customerDetails/saga";
import reportSaga from "./report/saga";
import noticePeriodSaga from "./noticePeriod/saga";
import newsLetterSaga from "./components/footer/saga";
import projectManagerLoginSaga from "./projectManagerLogin/saga";
import AcceptOrDenyNewAdminSaga from "./AcceptOrDenyNewAdmin/saga";
import SmallBannerSaga from "./components/smallBanner/saga";
import requestInquiryListSaga from "./faqCard/saga";
import ctrlSwiftLiteSaga from "./ctrlSwiftLitePlan/saga";

//--------->Partner Login
import partnerLoginSaga from "./partnerLogin/saga";

//--->company req and accept
import companyNewRequestsSaga from "./companyRequest/saga";
import acceptedPartnersSaga from "./acceptedCompany/saga";

//--------->self employee req and accept
import acceptedSelfEmployeeSaga from "./acceptedSelfEmployee1/saga";
import requestedSelfEmployeeSaga from "./selfEmployeeRequest/saga";

//-------->Partner Registration
import partnerRegisterSaga from "./partnerRegister/saga";

//-------->selfepm Registration
import selfepmRegisterSaga from "./selfEmployedReg/saga";
//--------->set New password 
import setNewPasswordSaga from "./setNewPassword/saga";

export const rootSaga = () =>
  function* root() {
    yield [fork(userSaga)];
    yield [fork(adminloginSaga)];
    yield [fork(getmailSaga)];
    yield [fork(forgotOtpSage)];
    yield [fork(resetSaga)];
    yield [fork(requestSaga)];
    yield [fork(salesAdminLoginSaga)];
    yield [fork(requestDemoSaga)];
    yield [fork(feedbackSaga)];
    yield [fork(registrationSaga)];
    //yield [fork(validateOtpSage )];
    //yield [fork(registrationpasswordSaga )];
    yield [fork(loginSaga)];
    // yield [fork(getmailcustomerSaga )];
    // yield[fork(forgotOtpCustomerSage)];
    // yield[fork(resetCustomerSaga)];
    yield [fork(detailsSaga)];
    yield [fork(serviceTaxSaga)];
    yield [fork(customizePageSaga)];
    yield [fork(editProfilesaga)];
    yield [fork(priceDetailsSaga)];
    yield [fork(dmasSaga)];
    yield [fork(changePlansaga)];
    yield [fork(viewInvoicesaga)];
    yield [fork(logoutSaga)];
    yield [fork(dmasAnnexureSaga)];
    //yield [fork(choosePlanssaga )];
    yield [fork(invoiceNumberSaga)];
    yield [fork(invoiceOtpSaga)];
    yield [fork(taxInvoicesaga)];
    yield [fork(contactUsSaga)];
    yield [fork(invoiceCreateSaga)];
    yield [fork(reportSaga)];
    //yield [fork(updateSaga )];
    yield [fork(upgradeSaga)];
    yield [fork(orderChangeSaga)];
    yield [fork(reguserSaga)];
    yield [fork(rateSaga)];
    yield [fork(discountSaga)];
    yield [fork(priceSaga)];
    yield [fork(terminateOrderSaga)];
    yield [fork(customerDetailsSaga)];
    yield [fork(noticePeriodSaga)];
    yield [fork(newsLetterSaga)];
    yield [fork(projectManagerLoginSaga)];
    yield [fork(AcceptOrDenyNewAdminSaga)];
    yield [fork(SmallBannerSaga)];
    yield [fork(requestInquiryListSaga)];
    yield [fork(ctrlSwiftLiteSaga)];

    yield [fork(partnerLoginSaga)];
    yield [fork(companyNewRequestsSaga)];
    yield [fork(acceptedPartnersSaga)];
    yield [fork(acceptedSelfEmployeeSaga)];
    yield [fork(requestedSelfEmployeeSaga)];
    yield [fork(partnerRegisterSaga)];
    yield [fork(selfepmRegisterSaga)];
    yield [fork(setNewPasswordSaga)];
    
  };
