import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import $ from 'jquery';
$(window).bind('resize', function () {
    var viewportWidth = window.innerWidth;
    if (viewportWidth < 767) {
      $(".logo_width").css("display","block");

    } 
    else{
        $(".logo_width").css("display","block");
  
    }
});

ReactDOM.render(<App />, document.getElementById("root"));
