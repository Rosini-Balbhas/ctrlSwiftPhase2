// import React,{Component} from "react";
// import { Button } from "react-bootstrap";

// class choose extends Component{
//     render(){
//         return(
//             <

//             <Button>
//                 Company Partner 
//             </Button>
            
//         );
//     }

// }